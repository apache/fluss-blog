"""Fail-closed Fluss ownership, approval, resource, and borrower predicates."""

from pathlib import Path
import math

GIB = 1073741824
GUIDE_QUOTE = "Host loop-mount steps require separate authorization and belong to the coordinating shell."
SCOPE = "One fresh task-owned physically allocated 4GiB ext4 file; -E nodiscard; loop mount, inspect, unmount, detach and remove only that file; ordinary pinned Docker container and owned network; no host configuration or package changes."


def require(value, message):
    if not value:
        raise ValueError(message)


def resource_limits(memory, free, usage, growth, preboot):
    require(memory >= (10 if preboot else 2) * GIB, "preboot memory" if preboot else "active memory")
    require(free >= 25 * GIB, "free disk below25GiB")
    require(usage < 94, "disk usage must remain below94%")
    require(growth <= 8 * GIB, "cumulative disk exceeds8GiB from first-task baseline")


def disk_growth(first_used, peak_used, current_used):
    return max(0, peak_used - first_used, current_used - first_used)


def reserve_four_gib(sample, first_used):
    projected_used = sample["used_bytes"] + 4 * GIB
    projected_free = sample["free_bytes"] - 4 * GIB
    projected_usage = math.ceil(100 * projected_used / (projected_used + projected_free))
    require(projected_usage < 94, "projected usage must remain below94% after4GiB allocation")
    require(projected_free >= 25 * GIB, "projected free disk below25GiB after4GiB allocation")
    require(disk_growth(first_used, sample["peak_used_bytes"], projected_used) <= 8 * GIB, "projected cumulative disk exceeds8GiB")


def abort_owned(stop, diagnostics):
    stop()
    diagnostics()


def ancestors(path):
    path = Path(path)
    require(path.is_absolute(), "absolute path required")
    for parent in (path, *path.parents):
        require(not parent.is_symlink(), "symlink ancestor: " + str(parent))


def fresh(path):
    ancestors(path)
    require(not path.exists(), "reuse forbidden: " + str(path))


def allocation(size, blocks, links):
    require(size == 4 * GIB, "exact logical4GiB")
    require(blocks * 512 >= 4 * GIB, "exact physical4GiB reservation")
    require(links == 1, "hardlink forbidden")


def overlaps(left, right):
    first, second = Path(left), Path(right)
    return first == second or first in second.parents or second in first.parents


def container_borrower(item, own_id, own_name, root, loop):
    for mount in item.get("Mounts", []):
        source = mount.get("Source", "")
        require(source != loop, "loop mount borrower")
        require(not overlaps(source, root), "storage borrower: " + item["Id"])
    config = item.get("HostConfig", {})
    for key in ("NetworkMode", "PidMode", "IpcMode"):
        mode = config.get(key, "")
        require(mode != "container:" + own_name, "namespace borrower")
        if own_id is not None:
            require(mode != "container:" + own_id, "namespace borrower")
        require(not mode.startswith("container:"), "unresolved namespace borrower")
    for device in config.get("Devices") or []:
        require(device["PathOnHost"] != loop, "loop device borrower")


def borrowers(items, own_id, own_name, root, loop):
    for item in items:
        if item["Id"] != own_id:
            container_borrower(item, own_id, own_name, root, loop)


def mount_identity(record, loop, mount, image, backing):
    require(record["target"] == str(mount), "exact mount target")
    require(record["source"] == loop, "exact mount source")
    require(record["fstype"] == "ext4", "exact ext4 filesystem")
    require({"nosuid", "nodev", "rw"} <= set(record["options"].split(",")), "mount options")
    require(backing == str(image), "exact loop backing file")
