"""Project private observations into the explicitly limited public evidence contract."""

import hashlib
import json
from pathlib import Path
from guards import require
from proof import digest, save
from public_schema import SCHEMA, HEAVY, OPERATIONS, validate_member


def encoded(value):
    return (json.dumps(value, indent=2, sort_keys=True) + "\n").encode()


def hash_value(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def raw_pin(raw):
    return {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def private_data(owned):
    data = {}
    for path in owned.evidence.rglob("*"):
        if path.is_file():
            require(not path.is_symlink(), "private evidence regular files")
            data["evidence/" + path.relative_to(owned.evidence).as_posix()] = path.read_bytes()
    return data


def load(data, name):
    return json.loads(data["evidence/" + name])


def private_contract(data, offer):
    import private_checks as checks
    binding = load(data, "build-binding.json")
    pins = load(data, "e2e/source-hashes.json")
    checks.inspect_result(data, binding, offer["run_id"])
    phases = checks.inspect_phases(data)
    checks.inspect_phase_contract(data, phases, offer)
    checks.inspect_runtime(data)
    checks.inspect_cleanup(data, phases)
    checks.inspect_monitor(data)
    require(binding["source_hashes"] == pins, "private build/runtime source equality")
    return binding


def identity(data):
    container, storage = load(data, "container-identity.json"), load(data, "storage-identity.json")
    image, network = load(data, "image-identity.json"), load(data, "network-identity.json")
    config = container["HostConfig"]
    caps = {"memory_bytes": config["Memory"], "swap_bytes": config["MemorySwap"], "nano_cpus": config["NanoCpus"],
            "pids": config["PidsLimit"], "privileged": config["Privileged"], "capabilities_count": len(config["CapAdd"] or []),
            "published_ports_count": len(config["PortBindings"] or {}), "log_type": config["LogConfig"]["Type"],
            "log_max_size": config["LogConfig"]["Config"]["max-size"], "log_max_file": config["LogConfig"]["Config"]["max-file"]}
    return {"container_id": container["Id"], "network_id": network["Id"], "image_id": image["Id"].removeprefix("sha256:"),
            "image_digest": image["RepoDigests"][0].split("@sha256:")[1], "loop": storage["loop"],
            "image_path_sha256": hash_value(storage["image"]), "mount_path_sha256": hash_value(storage["mount"]),
            "image_device": storage["image_identity"][0], "image_inode": storage["image_identity"][1],
            "size": storage["size"], "allocated_bytes": storage["allocated_bytes"], "format": storage["format"], "caps": caps,
            "writable_budget": load(data, "operator-inputs.json")["outside_budget"]["limits"]["docker_writable_bytes"],
            "foreign_before_sha256": hash_value(load(data, "unrelated-before.json")),
            "foreign_after_sha256": hash_value(load(data, "unrelated-after.json")),
            "inspect_sha256": hash_value([container, image, network])}


def phase_prefixes(data):
    return sorted(name.removesuffix(".completion.json") for name in data if name.endswith(".completion.json") and Path(name).name[:3].isdigit())


def phases(data):
    result = []
    for prefix in phase_prefixes(data):
        row = json.loads(data[prefix + ".completion.json"])
        name = Path(prefix).name[4:]
        require(name in OPERATIONS, "explicit public operation vocabulary")
        result.append({"operation": name, "pid": row["pid"], "process_group": row["process_group"],
                       "exit_code": row["exit_code"], "natural_exit": row["natural_exit"], "drained": row["drained"],
                       "timed_out": False, "started_gst": row["started_gst"], "ended_gst": row["ended_gst"],
                       "raw_sha256": raw_pin(data[prefix + ".completion.json"])["sha256"],
                       "stdout": raw_pin(data[prefix + ".stdout"]), "stderr": raw_pin(data[prefix + ".stderr"]),
                       "observation_sha256": raw_pin(data[prefix + ".stdout"])["sha256"],
                       "output_sha256": hash_value(data[prefix + ".stdout"].decode().strip()),
                       "subject_sha256": phase_subject(name, row["argv"])})
    return result


def phase_subject(name, argv):
    direct = {"allocate4GiB", "format-nodiscard", "attach-loop", "mount-owned", "remove-owned-container",
              "remove-owned-network", "sync-owned-data", "unmount-owned", "detach-owned-loop", "observe-cleanup-loops"}
    if name in direct:
        return hash_value(argv[-1])
    if name == "container-create":
        return hash_value(argv[argv.index("--name") + 1])
    return hash_value(None)


def observation(data, operation):
    rows = [prefix for prefix in phase_prefixes(data) if Path(prefix).name[4:] == operation]
    require(len(rows) == 1, "single private operation observation")
    return data[rows[0] + ".stdout"]


def cleanup(data):
    row = load(data, "cleanup-observations.json")
    return {"container_id": row["container_id"], "network_id": row["network_id"], "loop": row["loop"],
            "image_path_sha256": hash_value(row["image"]), "image_device": row["image_identity"][0],
            "image_inode": row["image_identity"][1], "remaining_container_ids": row["remaining_container_ids"],
            "remaining_network_ids": row["remaining_network_ids"],
            "remaining_mount_sha256": [hash_value(value) for value in row["remaining_mounts"]],
            "loop_observation": raw_pin(observation(data, "observe-cleanup-loops")),
            "file_errno": row["file_lstat"]["errno"], "file_path_sha256": hash_value(row["file_lstat"]["path"]),
            "raw_sha256": raw_pin(data["evidence/cleanup-observations.json"])["sha256"]}


def workspaces(data):
    result = []
    for phase in HEAVY:
        row = load(data, "workspace-" + phase + ".json")
        result.append({**{key: row[key] for key in ("source", "fstype", "target", "capacity_bytes", "available_bytes", "used_percent")},
                       "phase": phase, "layer_bytes": json.loads(observation(data, "layer-" + phase))["SizeRw"],
                       "df_sha256": raw_pin(observation(data, "workspace-" + phase))["sha256"],
                       "layer_sha256": raw_pin(observation(data, "layer-" + phase))["sha256"],
                       "paths_before": path_state(data, phase, "before" if phase != "packages" else "after"),
                       "paths_after": path_state(data, phase, "after")})
    return result


def path_state(data, phase, boundary):
    state = json.loads(observation(data, "paths-" + boundary + "-" + phase))
    mount = state["mount"]
    major, minor = map(int, mount["device"].split(":"))
    return {"mount_id": int(mount["id"]), "parent_id": int(mount["parent"]), "major": major, "minor": minor,
            "source": mount["source"], "fstype": mount["fstype"], "root": mount["root"], "target": mount["target"],
            "options_sha256": hash_value(mount["options"]),
            "ancestors": [{"path": name, "device": values[0], "inode": values[1]} for name, values in sorted(state["ancestors"].items())]}


def observations(data):
    release = load(data, "release-identity.json")
    return {"schema": SCHEMA, "identity": identity(data), "cleanup": cleanup(data), "workspaces": workspaces(data),
            "backend_before": [int(row.split()[0]) for row in load(data, "cluster-processes-before.json")],
            "backend_after": [int(row.split()[0]) for row in load(data, "cluster-processes-after.json")],
            "release_sha512": release["observed_sha512"], "release_bytes": release["bytes"],
            "config_before_sha256": hash_value([raw_pin(data["evidence/cluster-config-before/" + name]) for name in ("server.yaml", "zookeeper.properties")]),
            "config_tested_sha256": hash_value([raw_pin(data["evidence/cluster-config-tested/" + name]) for name in ("server.yaml", "zookeeper.properties")])}


def role(row):
    if row["name"] == "service":
        return "service"
    if row["exit_code"] == -9:
        return "kill"
    if row["name"].startswith("recover-"):
        return "recover"
    return "other"


def job(row):
    if "--job" in row["argv"]:
        return row["argv"][row["argv"].index("--job") + 1]
    return None


def stream_rows(raw, serial, channel):
    result = []
    for number, line in enumerate(raw.splitlines(keepends=True)):
        result.append({"worker": serial, "channel": channel, "line": number,
                       **raw_pin(line), "kind": event_kind(line)})
    return result


def event_kind(line):
    try:
        value = json.loads(line)
    except (ValueError, UnicodeDecodeError):
        return "diagnostic"
    if type(value) is dict and value.get("kind") in ("ACK", "RESULT", "REPLAY", "BARRIER", "FAILURE"):
        return value["kind"]
    return "diagnostic"


def workers(data, binding):
    records, streams = [], []
    for serial, row in enumerate(load(data, "e2e/commands.json")):
        prefix = "evidence/e2e/" + Path(row["prefix"]).name
        stdout, stderr = data[prefix + ".stdout.log"], data[prefix + ".stderr.log"]
        records.append({"serial": serial, "role": role(row), "name_sha256": hash_value(row["name"]), "pid": row["pid"],
                        "exit_code": row["exit_code"], "drained": row["collectors_finished"], "timed_out": row["timed_out"],
                        "started_gst": row["started_gst"], "ended_gst": row["ended_gst"], "job_sha256": hash_value(job(row)),
                        "jar_sha256": binding["jar_sha256"], "raw_sha256": hash_value(row),
                        "stdout": raw_pin(stdout), "stderr": raw_pin(stderr)})
        streams.extend(stream_rows(stdout, serial, "stdout"))
        streams.extend(stream_rows(stderr, serial, "stderr"))
    return records, streams


def result(data, binding, records):
    row = load(data, "e2e/manifest.json")
    return {"run_id": row["run_id"], "cases": sorted(row["case_status"]),
            "assertions": [{"name_sha256": hash_value(value["name"]), "expected_sha256": hash_value(value["expected"]),
                            "observed_sha256": hash_value(value["observed"])} for value in load(data, "e2e/assertions.json")],
            "workers": records, "error_count": int(row["error"] is not None), "cleanup_error_count": len(row["cleanup_errors"]),
            "source_sha256": hash_value(load(data, "e2e/source-hashes.json")),
            "raw_sha256": raw_pin(data["evidence/e2e/manifest.json"])["sha256"]}


def monitor_record(data):
    frozen = load(data, "export-monitor.json")
    return {"schema": SCHEMA, "baseline": frozen["baseline"], "peak": frozen["peak"], "thread_alive": frozen["thread_alive"],
            "error_count": int(frozen["error"] != "None"),
            "samples": [json.loads(line) for line in data["evidence/host-monitor-export.jsonl"].splitlines()]}


def project(owned, package):
    data = private_data(owned)
    binding = private_contract(data, {"run_id": owned.name, "manifest_sha256": owned.manifest})
    require(load(data, "e2e/source-hashes.json") == json.loads((package / "source-manifest.json").read_text()), "exact private runtime source pins")
    records, streams = workers(data, binding)
    build = {key: binding[key] for key in ("source_manifest_sha256", "jar_sha256", "jar_bytes", "FlussStore_class_sha256", "image", "jar_path_tested")}
    build["raw_sha256"] = raw_pin(data["evidence/build-binding.json"])["sha256"]
    members = {"observations.json": encoded(observations(data)), "build.json": encoded(build),
               "result.json": encoded(result(data, binding, records)), "phases.json": encoded(phases(data)),
               "monitor.json": encoded(monitor_record(data)),
               "workload-streams.jsonl": b"".join(encoded(row).replace(b"\n", b"") + b"\n" for row in streams)}
    for name in ("tested.jar", "FlussStore.class", "build.pom.xml"):
        members[name] = data["evidence/" + name]
    for name, raw in members.items():
        validate_member(name, raw)
    return members
