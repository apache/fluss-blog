"""V2 fixed stages with the one reserved workspace bind and bounded budgets."""

import json
from pathlib import Path
import re
import shutil
from guards import ancestors, fresh, require, reserve_four_gib
from proof import IMAGE, save, source_hashes
from placement import LAYOUT, check_layout, filesystem_record, host_paths

STAGES = [("prepare", 800), ("build", 1250), ("dependencies", 350), ("start", 150), ("verify", 650), ("stop", 90)]


def seed(package, owned):
    staging_budget(package, owned)
    for path in (package / "source").rglob("*"):
        if path.is_file():
            target = owned.root / "source" / path.relative_to(package / "source")
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(path, target)
    for name in ("inside.py", "proof.py", "guards.py", "placement.py", "workspace.py", "source-manifest.json"):
        shutil.copyfile(package / name, owned.root / "staging" / name)
    source_hashes(owned.root / "source", owned.root / "staging/source-manifest.json")


def staging_budget(package, owned):
    sources = [path for path in (package / "source").rglob("*") if path.is_file()]
    helpers = [package / name for name in ("inside.py", "proof.py", "guards.py", "placement.py", "workspace.py", "source-manifest.json")]
    demand = sum(path.stat().st_size for path in sources + helpers) + 2 * 65536
    require(demand <= owned.budget["source_staging_bytes"], "explicit source/staging and two64KiB identity budgets before copy")


def storage(owned, recorder):
    reserve_four_gib(recorder.monitor.sample(preboot=True), recorder.monitor.baseline)
    owned.create_image()
    recorder.run("allocate4GiB", ["fallocate", "-l", "4G", str(owned.image)], 60)
    owned.check_image()
    recorder.run("format-nodiscard", ["/usr/sbin/mkfs.ext4", "-m", "0", "-E", "nodiscard", str(owned.image)], 60)
    owned.check_image()
    prefix = recorder.run("attach-loop", ["losetup", "--find", "--show", str(owned.image)], 30)
    owned.loop = prefix.with_suffix(".stdout").read_text().strip()
    require(re.fullmatch(r"/dev/loop[0-9]+", owned.loop), "actual loop identity")
    owned.persist()
    recorder.run("mount-owned", ["mount", "-t", "ext4", "-o", "nosuid,nodev", owned.loop, str(owned.mount)], 30)
    owned.check_mount()
    save(owned.root / "staging/workspace-expected.json", host_paths(owned))
    save(owned.evidence / "storage-identity.json", {"loop": owned.loop, "image": str(owned.image),
         "image_identity": list(owned.image_identity), "size": owned.image.stat().st_size,
         "allocated_bytes": owned.image.stat().st_blocks * 512, "mount": str(owned.mount),
         "format": "mkfs.ext4 -m0 -E nodiscard"})


def boot(owned, recorder, budget):
    owned.budget = budget
    recorder.monitor.sample(preboot=True)
    prefix = recorder.run("network-create", ["docker", "network", "create", "--label", "fluss-guarded-owner=" + owned.name, owned.name], 30)
    owned.network_id = prefix.with_suffix(".stdout").read_text().strip()
    owned.persist()
    before_pull = recorder.monitor.sample(preboot=True)
    recorder.run("pull-pinned-image", ["docker", "pull", "--platform", "linux/amd64", IMAGE], 600)
    after_pull = recorder.monitor.sample(preboot=True)
    require(after_pull["used_bytes"] - before_pull["used_bytes"] <= budget["docker_image_bytes"], "explicit image physical allocation budget")
    prefix = recorder.run("container-create", container_argv(owned), 60)
    owned.container_id = prefix.with_suffix(".stdout").read_text().strip()
    owned.persist()
    owned.verify_container()
    owned.layer_monitoring = True
    recorder.monitor.preboot = False


def container_argv(owned):
    return ["docker", "run", "-d", "--name", owned.name, "--network", owned.name,
            "--label", "fluss-guarded-owner=" + owned.name, "--label", "fluss-proposal=" + owned.manifest,
            "--memory", "8g", "--memory-swap", "8g", "--cpus", "3", "--pids-limit", "1024",
            "--log-driver", "json-file", "--log-opt", "max-size=4m", "--log-opt", "max-file=2",
            "--mount", "type=bind,source=" + str(owned.root) + ",target=/lab",
            "--mount", "type=bind,source=" + str(owned.root / "source") + ",target=/lab/source",
            "--mount", "type=bind,source=" + str(owned.mount) + ",target=/lab/runtime",
            IMAGE, "sleep", "infinity"]


def workspace(owned, recorder, stage):
    check_layout(LAYOUT)
    owned.check_mount()
    owned.verify_container()
    host_paths(owned)
    prefix = recorder.run("workspace-" + stage, ["docker", "exec", owned.name, "df", "-B1",
                         "--output=source,fstype,target,size,avail,pcent", "/lab/runtime"], 30)
    observed = filesystem_record(prefix.with_suffix(".stdout").read_text(), owned.loop)
    save(owned.evidence / ("workspace-" + stage + ".json"), observed)
    prefix = recorder.run("layer-" + stage, ["docker", "inspect", "--size", "--format",
                          '{"Id":{{json .Id}},"SizeRw":{{json .SizeRw}}}', owned.container_id], 30)
    layer = json.loads(prefix.with_suffix(".stdout").read_text())
    require(set(layer) == {"Id", "SizeRw"} and layer["Id"] == owned.container_id, "scoped layer observation")
    require(layer["SizeRw"] <= owned.budget["docker_writable_bytes"], "explicit container writable budget")


def workload_stage(owned, recorder, name, timeout):
    paths(owned, recorder, name, "before")
    prefix = recorder.run(name, ["docker", "exec", "--env", "PYTHONDONTWRITEBYTECODE=1", owned.name,
               "python3", "/lab/staging/inside.py", name, "--run-id", owned.name], timeout)
    if name == "dependencies":
        require("dependency:3.7.0:tree" in prefix.with_suffix(".stdout").read_text(), "recorded dependency plugin3.7.0")
    workspace(owned, recorder, name)
    paths(owned, recorder, name, "after")


def paths(owned, recorder, stage, boundary):
    owned.check_mount()
    owned.verify_container()
    host_paths(owned)
    prefix = recorder.run("paths-" + boundary + "-" + stage,
                          ["docker", "exec", "--env", "PYTHONDONTWRITEBYTECODE=1", owned.name,
                           "python3", "/lab/staging/workspace.py"], 30)
    namespace_state(owned, json.loads(prefix.with_suffix(".stdout").read_text()))


def namespace_state(owned, state):
    require(set(state) == {"mount", "ancestors"}, "exact namespace workspace observation")
    require(state["ancestors"]["/lab/runtime"] == [owned.workspace_expected["device"], owned.workspace_expected["inode"]], "bound namespace root inode")
    mounted = state["mount"]
    require(mounted["source"] == owned.loop and mounted["fstype"] == "ext4", "bound namespace loop filesystem")
    require(mounted["root"] == "/" and mounted["target"] == "/lab/runtime", "bound namespace mount root")
    previous = getattr(owned, "container_workspace_state", None)
    if previous is not None:
        require(previous["mount"] == mounted, "host-retained container mount generation")
        require(all(state["ancestors"].get(path) == value for path, value in previous["ancestors"].items()), "host-retained namespace ancestor inodes")
    owned.container_workspace_state = state


def packages(owned, recorder):
    owned.check_mount()
    owned.verify_container()
    host_paths(owned)
    recorder.run("container-apt-update", ["docker", "exec", owned.name, "apt-get", "update"], 300)
    recorder.run("container-packages", ["docker", "exec", "--env", "DEBIAN_FRONTEND=noninteractive", owned.name,
                 "apt-get", "install", "-y", "--no-install-recommends", "python3", "procps", "iproute2"], 300)
    workspace(owned, recorder, "packages")
    paths(owned, recorder, "packages", "after")


def collect_native_logs(owned, monitor):
    source = owned.mount / "attempt-02/fluss-1.0.0/log"
    require(source.is_dir(), "native logs before owned cleanup")
    paths = [path for path in source.iterdir() if path.is_file()]
    require(bool(paths), "native logs must be retained")
    require(sum(path.stat().st_size for path in paths) <= 64 * 1048576, "native logs64MiB export bound")
    destination = owned.evidence / "cluster-logs"
    fresh(destination)
    destination.mkdir()
    for path in paths:
        monitor.check(force=True)
        ancestors(path)
        shutil.copyfile(path, destination / path.name)
