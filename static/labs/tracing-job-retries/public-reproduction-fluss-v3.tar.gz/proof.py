"""Hash and real build/result binding for the unchanged portable source."""

import hashlib
import json
from pathlib import Path
import zipfile

from guards import ancestors, require

SOURCE_PIN = "ee2d837ea24e7513f15e9ac5ccfb433501eeb37a010ccf94db65839c80011be2"
IMAGE = "docker.io/library/maven@sha256:82e47241881f23ad774f5db8829efca15758e8fdb5b1d64ea9f8d6420a85068e"
RELEASE_URL = "https://downloads.apache.org/fluss/fluss-1.0.0/fluss-1.0.0-bin.tgz"
RELEASE_SHA512 = "4cc134d1c5e7b9b07754b4d38903b9c6e4075d66aa7cf04eb3b053fa5095266f1d141e147417d292b3e93b642b24ea06630709de85562c3a829b640ccb7d52ca"
RELEASE_SIZE = 522178300


def digest_bytes(value):
    return hashlib.sha256(value).hexdigest()


def digest(path, algorithm="sha256"):
    value = hashlib.new(algorithm)
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1048576), b""):
            value.update(block)
    return value.hexdigest()


def file_pin(path, expected, size=None):
    ancestors(path)
    require(path.is_file(), "regular pinned file")
    if size is not None:
        require(path.stat().st_size == size, "pinned file size")
    require(digest(path) == expected, "pinned file digest")


def save(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


def source_hashes(source, manifest):
    file_pin(manifest, SOURCE_PIN)
    pins = json.loads(manifest.read_text())
    require(len(pins) == 15, "exact15 v2 source inputs")
    actual = {path.relative_to(source).as_posix() for path in source.rglob("*")
              if path.is_file() and "target" not in path.relative_to(source).parts}
    require(actual == set(pins), "exact source file set before build/runtime")
    for name, expected in pins.items():
        file_pin(source / name, expected)
    return pins


def code_hashes(pins):
    values = {name: value for name, value in pins.items()
              if name not in (".gitignore", "README.md", "E2E_SPEC.md")}
    require(len(values) == 12, "exact12 runtime/build inputs")
    return values


def build_binding(source, manifest, evidence, target):
    pins = source_hashes(source, manifest)
    jar = target / "fluss-retry-lab.jar"
    compiled = target / "classes/lab/retry/FlussStore.class"
    with zipfile.ZipFile(jar) as archive:
        entry = archive.read("lab/retry/FlussStore.class")
    require(entry == compiled.read_bytes(), "compiled FlussStore class to tested jar")
    result = {"source_manifest_sha256": SOURCE_PIN, "source_hashes": pins,
              "runtime_code_hashes": code_hashes(pins), "jar_sha256": digest(jar),
              "jar_bytes": jar.stat().st_size, "FlussStore_class_sha256": digest(compiled),
              "class_entry_matches_compiler_output": True, "image": IMAGE,
              "jar_path_tested": str(jar)}
    save(evidence / "build-binding.json", result)
    return result


def result_binding(directory, source, manifest, binding, run_id, target):
    observed = json.loads((directory / "manifest.json").read_text())
    assertions = json.loads((directory / "assertions.json").read_text())
    commands = json.loads((directory / "commands.json").read_text())
    pins = source_hashes(source, manifest)
    runtime = json.loads((directory / "source-hashes.json").read_text())
    require(all(runtime[name] == value for name, value in pins.items()), "actual runtime input binding")
    require(digest(target / "fluss-retry-lab.jar") == binding["jar_sha256"], "tested jar unchanged")
    require(observed["run_id"] == run_id, "fresh observed run identity")
    require(observed["status"] == "PASSED", "actual run failed")
    require(observed["error"] is None and observed["cleanup_errors"] == [], "actual cleanup/error")
    require(observed["cases_started"] == 7 and observed["specified_cases"] == 7, "all7 cases")
    require(len(assertions) == 234 and observed["assertion_count"] == 234, "all234 assertions")
    require(all(row["passed"] is True for row in assertions), "actual assertion failures")
    verify_workers(commands, observed)
    verify_service(commands)
    verify_jar_commands(commands, binding["jar_path_tested"], run_id)
    return {"status": "OBSERVED_PASSED", "run_id": run_id, "assertions": len(assertions),
            "runtime_code_hashes": code_hashes(pins), "jar_sha256": binding["jar_sha256"],
            "source_manifest_sha256": SOURCE_PIN, "raw_manifest_sha256": digest(directory / "manifest.json")}


def verify_workers(commands, manifest):
    require(len(manifest["case_status"]) == 7, "exact7 observed case statuses")
    require(all(value["status"] == "PASSED" for value in manifest["case_status"].values()), "case failure")
    require(all(row["collectors_finished"] and not row["timed_out"] for row in commands), "worker stream drainage")
    killed = [row for row in commands if row["exit_code"] == -9]
    require(len(killed) == 6, "six actual SIGKILL exits")
    verify_restarts(commands, killed)


def verify_restarts(commands, killed):
    require(len({row["pid"] for row in killed}) == 6, "six distinct killed workers")
    recovered = [row for row in commands if row["name"].startswith("recover-")]
    require(len(recovered) >= 6, "actual restarted workers")
    require(not {row["pid"] for row in killed} & {row["pid"] for row in recovered}, "new JVM PID")


def verify_service(commands):
    services = [row for row in commands if row["name"] == "service"]
    require(len(services) == 1, "one independent surviving HTTP fixture")
    service = services[0]
    killed = [row for row in commands if row["exit_code"] == -9]
    require(service["pid"] not in {row["pid"] for row in killed}, "fixture separate from killed workers")
    require(service["started_gst"] <= min(row["started_gst"] for row in killed), "fixture started before kills")
    require(service["ended_gst"] >= max(row["ended_gst"] for row in killed), "fixture survived all six kills")


def verify_jar_commands(commands, jar, run_id):
    for row in commands:
        argv = row["argv"]
        if "-jar" in argv:
            require(argv[argv.index("-jar") + 1] == jar, "actual Java command tested bound jar")
        if "--job" in argv:
            require(argv[argv.index("--job") + 1].startswith(run_id + "/"), "actual fresh job identity")
