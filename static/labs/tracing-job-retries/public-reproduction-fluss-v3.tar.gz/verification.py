"""Independent real archive inspection of the declared closed public projection."""

import hashlib
import io
import json
from pathlib import Path
import tarfile
import zipfile
from guards import GIB, require
from package_integrity import canonical
from proof import SOURCE_PIN, IMAGE, RELEASE_SIZE
from public_schema import MAX_EXPORT, CASES, STEPS, CLEAN, CHECKS, HEAVY, VALIDATORS, BINARY, PIN, decode, validate_member
from supervision import check_sample


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def value_sha(value):
    return sha(json.dumps(value, sort_keys=True, separators=(",", ":")).encode())


def obj(data, name):
    return decode(data["evidence/" + name])


def read_archive(path):
    require(path.stat().st_size <= MAX_EXPORT, "bounded real archive")
    data, total = {}, 0
    with tarfile.open(path, "r:gz") as archive:
        for member in archive:
            require(len(data) < 1025, "bounded archive members")
            name = canonical(member.name)
            require(member.isfile() and name not in data, "regular unique archive member")
            require(0 <= member.size <= MAX_EXPORT, "bounded archive member")
            total += member.size
            require(total <= MAX_EXPORT + 1048576, "bounded expanded evidence")
            data[name] = archive.extractfile(member).read()
    return data


def inspect_index(data, offer, package):
    from export import checker_pins
    index = decode(data["evidence-index.json"])
    fields = {"schema", "run_id", "manifest_sha256", "files"} | set(checker_pins(package))
    require(set(index) == fields and index["schema"] == "fluss-evidence-index-v2", "closed evidence index")
    require(sha(data["evidence-index.json"]) == offer["index_sha256"], "actual archive index hash")
    require(index["run_id"] == offer["run_id"] and index["manifest_sha256"] == offer["manifest_sha256"], "index identity binding")
    for key, value in checker_pins(package).items():
        require(index[key] == offer[key] == value, "declared projection/checker pin")
    require(set(data) == set(index["files"]) | {"evidence-index.json"}, "exact export index member set")
    for name, pin in index["files"].items():
        PIN(pin)
        require(len(data[name]) == pin["bytes"] and sha(data[name]) == pin["sha256"], "actual indexed archive byte binding")
        inspect_member(data, name, package)
    inspect_member_sets(data, package)


def inspect_member_sets(data, package):
    expected = {"evidence/" + name for name in set(VALIDATORS) | BINARY | {"workload-streams.jsonl"}}
    require({name for name in data if name.startswith("evidence/")} == expected, "exact projected evidence set")
    manifest = json.loads((package / "PUBLIC_MANIFEST.json").read_text())
    require({name for name in data if name.startswith("package/")} == {"package/" + name for name in [*manifest["files"], "PUBLIC_MANIFEST.json"]}, "exact pinned package members")


def inspect_member(data, name, package):
    if name.startswith("evidence/"):
        validate_member(name.removeprefix("evidence/"), data[name])
        return
    require(name.startswith("package/"), "export path allowlist")
    require(data[name] == (package / name.removeprefix("package/")).read_bytes(), "independent pinned public bytes")


def inspect_source(data):
    require(sha(data["package/source-manifest.json"]) == SOURCE_PIN, "exact15 source manifest")
    pins = decode(data["package/source-manifest.json"])
    require(len(pins) == 15, "exact15 source members")
    for name, expected in pins.items():
        require(sha(data["package/source/" + name]) == expected, "actual retained source bytes")
    return pins


def inspect_build(data):
    binding = obj(data, "build.json")
    jar, compiled = data["evidence/tested.jar"], data["evidence/FlussStore.class"]
    require(binding["source_manifest_sha256"] == SOURCE_PIN and binding["image"] == IMAGE, "observed build source/image binding")
    require(sha(jar) == binding["jar_sha256"] and len(jar) == binding["jar_bytes"], "actual tested jar")
    require(sha(compiled) == binding["FlussStore_class_sha256"] and len(compiled) <= 1048576, "actual bounded compiler class")
    with zipfile.ZipFile(io.BytesIO(jar)) as archive:
        require(archive.getinfo("lab/retry/FlussStore.class").file_size == len(compiled), "bounded jar class entry")
        require(archive.read("lab/retry/FlussStore.class") == compiled, "actual jar/compiler class equality")
    original = data["package/source/pom.xml"].decode()
    paths = "<directory>/lab/runtime/build-target</directory><sourceDirectory>/lab/source/src/main/java</sourceDirectory>"
    require(data["evidence/build.pom.xml"].decode() == original.replace("<build>", "<build>" + paths), "exact path-only POM")
    return binding


def inspect_result(data, binding, run_id):
    result = obj(data, "result.json")
    pins = decode(data["package/source-manifest.json"])
    require(result["source_sha256"] == sha(json.dumps(pins, sort_keys=True, separators=(",", ":")).encode()), "exact runtime source projection")
    require(result["run_id"] == run_id and result["error_count"] == result["cleanup_error_count"] == 0, "actual result/error identity")
    require(len(result["cases"]) == 7 and set(result["cases"]) == CASES, "exact seven cases")
    require(len(result["assertions"]) == 234, "all234 observed assertion pairs")
    require(all(row["expected_sha256"] == row["observed_sha256"] for row in result["assertions"]), "observed assertion equality bindings")
    workers = result["workers"]
    require(len({row["pid"] for row in workers}) == len(workers), "distinct actual worker PIDs")
    require([row["serial"] for row in workers] == list(range(len(workers))), "exact worker sequence")
    for row in workers:
        require(row["pid"] > 0 and row["drained"] and not row["timed_out"], "worker natural collector provenance")
        require(row["ended_gst"] >= row["started_gst"] and row["jar_sha256"] == binding["jar_sha256"], "worker timing/tested jar binding")
    inspect_recovery(workers)
    inspect_streams(data, workers)


def inspect_recovery(workers):
    killed = [row for row in workers if row["exit_code"] == -9]
    recovered = [row for row in workers if row["role"] == "recover"]
    services = [row for row in workers if row["role"] == "service"]
    require(len(killed) == 6, "six actual SIGKILL exits")
    require(all(row["role"] == "kill" for row in killed), "actual kill roles")
    require(len(recovered) >= 6 and len(services) == 1, "restarted workers/separate fixture")
    match_recovery(killed, recovered)
    inspect_service(services[0], killed)


def match_recovery(killed, recovered):
    for row in killed:
        require(any(value["job_sha256"] == row["job_sha256"] and value["pid"] != row["pid"] for value in recovered), "exact killed/recovery job binding")


def inspect_service(service, killed):
    require(service["started_gst"] <= min(row["started_gst"] for row in killed), "service before all kills")
    require(service["ended_gst"] >= max(row["ended_gst"] for row in killed), "service survived all kills")


def inspect_streams(data, workers):
    rows = [decode(line) for line in data["evidence/workload-streams.jsonl"].splitlines()]
    require(all(row["worker"] < len(workers) for row in rows), "stream actual worker binding")
    for worker in workers:
        for channel in ("stdout", "stderr"):
            stream = [row for row in rows if row["worker"] == worker["serial"] and row["channel"] == channel]
            require([row["line"] for row in stream] == list(range(len(stream))), "exact bounded stream line sequence")
            require(sum(row["bytes"] for row in stream) == worker[channel]["bytes"], "observed full stream length binding")


def inspect_phases(data):
    rows = obj(data, "phases.json")
    records = {row["operation"]: row for row in rows}
    require(len(records) == len(rows), "unique observed operations")
    require(set(STEPS + CLEAN + CHECKS) <= set(records), "complete observed lifecycle")
    require([row["operation"] for row in rows if row["operation"] in STEPS + CLEAN + CHECKS] == STEPS + CLEAN + CHECKS, "exact observed phase order")
    for row in rows:
        require(row["exit_code"] == 0 and row["natural_exit"] and row["drained"] and not row["timed_out"], "actual phase natural0/drain")
        require(row["pid"] > 0 and row["process_group"] == row["pid"], "actual registered process group")
        require(row["ended_gst"] >= row["started_gst"], "actual phase start/end")
        require(row["observation_sha256"] == row["stdout"]["sha256"], "phase observation binding")
    return records


def inspect_runtime(data, phases):
    record = obj(data, "observations.json")
    identity = record["identity"]
    require(identity["size"] == 4 * GIB and identity["allocated_bytes"] >= 4 * GIB, "physical4GiB reservation")
    require(identity["image_digest"] == IMAGE.split("@sha256:")[1], "exact observed image digest")
    require(identity["foreign_before_sha256"] == identity["foreign_after_sha256"], "current foreign preservation binding")
    require(record["backend_before"] == record["backend_after"] and len(set(record["backend_before"])) == 3, "three surviving native backend PIDs")
    require(record["release_bytes"] == RELEASE_SIZE, "exact release bytes")
    inspect_caps(identity["caps"])
    require([row["phase"] for row in record["workspaces"]] == HEAVY, "all heavy workspace observations")
    for row in record["workspaces"]:
        require(row["source"] == identity["loop"] and 3.5 * GIB <= row["capacity_bytes"] <= 4 * GIB, "exact workspace loop/capacity")
        require(row["used_percent"] < 85 and row["layer_bytes"] <= identity["writable_budget"], "unchanged workspace/layer guards")
        require(row["df_sha256"] == phases["workspace-" + row["phase"]]["stdout"]["sha256"], "filesystem operation binding")
        require(row["layer_sha256"] == phases["layer-" + row["phase"]]["stdout"]["sha256"], "scoped layer observation binding")
    inspect_workspace_chain(record["workspaces"], identity["loop"], phases)
    inspect_resource_bindings(record, phases)
    return record


def inspect_workspace_chain(rows, loop, phases):
    previous = None
    for row in rows:
        before, after = row["paths_before"], row["paths_after"]
        require(before["source"] == after["source"] == loop, "exact guarded path loop")
        if previous is not None:
            same_paths(previous, before)
            require("paths-before-" + row["phase"] in phases, "preallocation path probe observed")
        same_paths(before, after)
        require("paths-after-" + row["phase"] in phases, "postallocation path probe observed")
        previous = after


def same_paths(before, after):
    keys = ("mount_id", "parent_id", "major", "minor", "source", "fstype", "root", "target", "options_sha256")
    require(all(before[key] == after[key] for key in keys), "unchanged workspace mount generation")
    prior = {row["path"]: [row["device"], row["inode"]] for row in before["ancestors"]}
    current = {row["path"]: [row["device"], row["inode"]] for row in after["ancestors"]}
    require(len(current) == len(after["ancestors"]), "unique existing workspace ancestors")
    require("/lab/runtime" in current, "observed existing workspace root")
    require(all(current.get(path) == value for path, value in prior.items()), "unchanged existing ancestor identities")
    device = current["/lab/runtime"][0]
    require(all(row["device"] == device for row in after["ancestors"]), "all ancestors on loop device")


def inspect_resource_bindings(record, phases):
    identity, cleanup = record["identity"], record["cleanup"]
    created = {"attach-loop": identity["loop"], "container-create": identity["container_id"], "network-create": identity["network_id"]}
    for operation, value in created.items():
        require(phases[operation]["output_sha256"] == value_sha(value), "actual created resource observation binding")
    subjects = {"allocate4GiB": identity["image_path_sha256"], "format-nodiscard": identity["image_path_sha256"],
                "attach-loop": identity["image_path_sha256"], "mount-owned": identity["mount_path_sha256"],
                "remove-owned-container": value_sha(identity["container_id"]), "remove-owned-network": value_sha(identity["network_id"]),
                "sync-owned-data": identity["mount_path_sha256"], "unmount-owned": identity["mount_path_sha256"],
                "detach-owned-loop": value_sha(identity["loop"]), "observe-cleanup-loops": identity["image_path_sha256"]}
    for operation, expected in subjects.items():
        require(phases[operation]["subject_sha256"] == expected, "exact allocated/removed resource subject binding")
    inspect_inventory_bindings(cleanup, phases)


def inspect_inventory_bindings(cleanup, phases):
    for operation, field in (("containers", "remaining_container_ids"), ("networks", "remaining_network_ids")):
        expected = value_sha("\n".join(cleanup[field]))
        require(phases["observe-cleanup-" + operation]["output_sha256"] == expected, "actual absence inventory binding")


def inspect_caps(caps):
    require(caps["memory_bytes"] == caps["swap_bytes"] == 8 * GIB, "actual memory/swap limits")
    require(caps["nano_cpus"] == 3000000000 and caps["pids"] == 1024, "actual CPU/PID limits")
    require(caps["privileged"] is False and caps["capabilities_count"] == caps["published_ports_count"] == 0, "actual ordinary container")


def inspect_cleanup(record):
    identity, cleanup = record["identity"], record["cleanup"]
    for key in ("container_id", "network_id", "loop", "image_path_sha256", "image_device", "image_inode"):
        require(cleanup[key] == identity[key], "exact observed cleanup identity")
    require(identity["container_id"] not in cleanup["remaining_container_ids"], "owned container absent in query projection")
    require(identity["network_id"] not in cleanup["remaining_network_ids"], "owned network absent in query projection")
    require(identity["mount_path_sha256"] not in cleanup["remaining_mount_sha256"], "owned mount absent in query projection")
    require(cleanup["loop_observation"]["bytes"] == 0 and cleanup["loop_observation"]["sha256"] == sha(b""), "actual empty loop query")
    require(cleanup["file_errno"] == 2 and cleanup["file_path_sha256"] == identity["image_path_sha256"], "observed owned file ENOENT")


def inspect_monitor(data):
    frozen = obj(data, "monitor.json")
    require(frozen["thread_alive"] and frozen["error_count"] == 0, "original monitor active at export")
    rows = frozen["samples"]
    require(len(rows) >= 2 and rows[0]["preboot"], "preallocation through cleanup samples")
    peak = frozen["baseline"]
    for row in rows:
        check_sample(row, preboot=row["preboot"])
        require(row["peak_used_bytes"] >= max(peak, row["used_bytes"]), "monotonic cumulative peak")
        require(row["growth_bytes"] == max(0, row["peak_used_bytes"] - frozen["baseline"]), "immutable original baseline growth")
        peak = row["peak_used_bytes"]
    require(peak == frozen["peak"], "full frozen peak binding")


def inspect(data, offer, package):
    inspect_index(data, offer, package)
    inspect_source(data)
    binding = inspect_build(data)
    inspect_result(data, binding, offer["run_id"])
    phases = inspect_phases(data)
    record = inspect_runtime(data, phases)
    inspect_cleanup(record)
    inspect_monitor(data)
    return {"checked_result_sha256": sha(data["evidence/result.json"]),
            "checked_build_sha256": sha(data["evidence/build.json"]),
            "checked_cleanup_sha256": sha(data["evidence/observations.json"])}
