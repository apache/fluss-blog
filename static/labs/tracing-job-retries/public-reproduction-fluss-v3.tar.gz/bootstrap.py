"""Externally pin this seed before fresh regular-file extraction; standard library only."""

import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import tarfile


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    value = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1048576), b""):
            value.update(block)
    return value.hexdigest()


def ancestors(path):
    require(path.is_absolute(), "absolute bootstrap path")
    for parent in (path, *path.parents):
        require(not parent.is_symlink(), "bootstrap symlink ancestor")


def member_name(member):
    name = PurePosixPath(member.name)
    require(member.isfile(), "bootstrap regular members only")
    require(not name.is_absolute() and ".." not in name.parts, "bootstrap path escape")
    require(member.name == name.as_posix() and bool(name.parts), "bootstrap canonical path")
    require(member.size <= 1048576, "bootstrap bounded source member")
    return member.name


def extract(archive_path, archive_sha, manifest_sha, destination):
    ancestors(archive_path)
    ancestors(destination)
    require(sha(archive_path) == archive_sha, "external package archive hash")
    require(not destination.exists() and destination.parent.is_dir(), "fresh bootstrap destination")
    with tarfile.open(archive_path, "r:gz") as archive:
        members = archive.getmembers()
        require(len(members) <= 64, "bootstrap bounded source members")
        names = [member_name(member) for member in members]
        require(len(set(names)) == len(names), "bootstrap duplicate member")
        require(sum(member.size for member in members) <= 4 * 1048576, "bootstrap4MiB source bound")
        inspect_manifest(archive, members, manifest_sha)
        destination.mkdir(mode=0o700)
        for member in members:
            target = destination / member.name
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open("xb") as stream:
                stream.write(archive.extractfile(member).read())


def inspect_manifest(archive, members, expected):
    by_name = {member.name: member for member in members}
    raw = archive.extractfile(by_name["PUBLIC_MANIFEST.json"]).read()
    require(hashlib.sha256(raw).hexdigest() == expected, "external public manifest hash")
    manifest = json.loads(raw)
    require(manifest["schema"] == "fluss-public-manifest-v3", "bootstrap public manifest schema")
    require(set(by_name) == set(manifest["files"]) | {"PUBLIC_MANIFEST.json"}, "bootstrap exact package file set")
    for name, pin in manifest["files"].items():
        raw = archive.extractfile(by_name[name]).read()
        require(len(raw) == pin["bytes"] and hashlib.sha256(raw).hexdigest() == pin["sha256"], "bootstrap package byte binding")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archive", type=Path, required=True)
    parser.add_argument("--archive-sha256", required=True)
    parser.add_argument("--manifest-sha256", required=True)
    parser.add_argument("--destination", type=Path, required=True)
    args = parser.parse_args()
    extract(args.archive, args.archive_sha256, args.manifest_sha256, args.destination)
    print("SOURCE_EXTRACTED; NO_RUNTIME_CREDIT")


if __name__ == "__main__":
    main()
