"""Bounded command drainage and five-second host guard for this one Fluss run."""

from datetime import datetime, timedelta, timezone
import json
import math
import os
from pathlib import Path
import signal
import subprocess
import threading
import time

from guards import abort_owned, disk_growth, require, resource_limits
from proof import save


def timestamp():
    return datetime.now(timezone(timedelta(hours=4))).isoformat()


def output(argv, timeout=30):
    result = subprocess.run(argv, stdin=subprocess.DEVNULL, capture_output=True, timeout=timeout)
    require(len(result.stdout) + len(result.stderr) <= 4 * 1048576, "bounded diagnostic output")
    require(result.returncode == 0, "command failed: " + repr(argv) + ": " + result.stderr.decode(errors="replace"))
    return result.stdout.decode()


def host_sample(path, baseline, peak):
    memory = dict(line.split(":", 1) for line in Path("/proc/meminfo").read_text().splitlines())
    available = int(memory["MemAvailable"].split()[0]) * 1024
    fs = os.statvfs(path)
    used = (fs.f_blocks - fs.f_bfree) * fs.f_frsize
    free = fs.f_bavail * fs.f_frsize
    usage = math.ceil(100 * used / (used + free))
    return {"at_gst": timestamp(), "memory_available_bytes": available, "free_bytes": free,
            "usage_percent": usage, "used_bytes": used, "peak_used_bytes": max(peak, used),
            "growth_bytes": disk_growth(baseline, peak, used)}


def check_sample(sample, preboot=False):
    resource_limits(sample["memory_available_bytes"], sample["free_bytes"],
                    sample["usage_percent"], sample["growth_bytes"], preboot)


def evidence_size(path):
    return sum(item.stat().st_size for item in path.rglob("*") if item.is_file())


class Monitor:
    def __init__(self, owned, baseline, peak, deadline):
        self.owned, self.baseline, self.peak = owned, baseline, peak
        self.deadline = deadline
        self.error = None
        self.finished = threading.Event()
        self.last_sample = 0
        self.latest = None
        self.pending_samples = []
        self.recorder = None
        self.maximum_used = None
        self.preboot = True
        self.failure_sample = None
        self.sample_lock = threading.Lock()
        self.thread = threading.Thread(target=self.watch, name="fluss-host-guard")

    def record_sample(self, sample):
        self.pending_samples.append(sample)
        if not self.owned.evidence.is_dir():
            return
        with (self.owned.evidence / "host-monitor.jsonl").open("a") as stream:
            for value in self.pending_samples:
                stream.write(json.dumps(value, sort_keys=True) + "\n")
        self.pending_samples.clear()

    def cancel_owned(self):
        try:
            if self.recorder is not None:
                self.recorder.cancel_active()
        finally:
            self.owned.stop()

    def sample(self, preboot=False):
        with self.sample_lock:
            if self.error is not None:
                raise RuntimeError("host guard already failed: " + str(self.error))
            try:
                return self.read_sample(preboot)
            except Exception as failure:
                self.error = failure
                self.failure_sample = self.latest
                raise

    def read_sample(self, preboot):
        self.latest = None
        sample = host_sample(self.owned.root.parent, self.baseline, self.peak)
        sample["preboot"] = preboot or self.preboot
        self.latest = sample
        self.last_sample = time.monotonic()
        self.peak = sample["peak_used_bytes"]
        check_sample(sample, sample["preboot"])
        require(time.monotonic() < self.deadline, "whole-run3600s deadline")
        if self.maximum_used is not None:
            require(sample["used_bytes"] <= self.maximum_used, "explicit outside allocation budget exceeded")
        require(Path("/proc/sys/vm/max_map_count").read_text().strip() == "65530", "original sysctl unchanged")
        require(evidence_size(self.owned.evidence) <= 256 * 1048576, "evidence256MiB limit")
        logs = self.owned.mount / "attempt-02/fluss-1.0.0/log"
        require(evidence_size(logs) <= 64 * 1048576, "native Fluss logs64MiB limit")
        self.check_layer_budget()
        self.record_sample(sample)
        return sample

    def check_layer_budget(self):
        if not self.owned.layer_monitoring:
            return
        row = json.loads(output(["docker", "inspect", "--size", self.owned.container_id]))[0]
        require(row["SizeRw"] <= self.owned.budget["docker_writable_bytes"], "explicit writable layer budget")

    def trip(self, failure):
        self.error = failure
        abort_owned(self.cancel_owned, lambda: save(self.owned.evidence / "resource-failure.json",
                    {"error": str(failure), "actual_sample": self.failure_sample,
                     "at_gst": timestamp(), "stopped_before_diagnostics": True}))

    def watch(self):
        while not self.finished.wait(5):
            try:
                self.sample()
            except Exception as failure:
                try:
                    self.trip(failure)
                except Exception as stop_failure:
                    self.error = stop_failure
                return

    def check(self, force=False):
        if self.error is not None:
            raise RuntimeError("host guard failed: " + str(self.error))
        try:
            if force or time.monotonic() - self.last_sample >= 5:
                self.sample()
        except Exception as failure:
            self.trip(failure)
            raise

    def close(self):
        self.finished.set()
        self.thread.join(timeout=40)
        require(not self.thread.is_alive(), "monitor must drain")


def collect(stream, path, state, key):
    count = 0
    try:
        with path.open("xb") as target:
            for block in iter(lambda: stream.read(65536), b""):
                target.write(block)
                target.flush()
                count += len(block)
                if count > 32 * 1048576:
                    state["overflow"].set()
        state["done"].add(key)
    except Exception as failure:
        state["errors"].append(str(failure))
        state["overflow"].set()
    finally:
        stream.close()


class Recorder:
    def __init__(self, evidence, monitor):
        self.evidence, self.monitor = evidence, monitor
        self.serial = 0
        self.active = set()
        self.active_lock = threading.Lock()
        monitor.recorder = self

    def cancel_active(self):
        with self.active_lock:
            for proc in self.active:
                kill_registered(proc)

    def cancel(self, proc):
        try:
            self.monitor.owned.stop()
        finally:
            if proc.poll() is None:
                os.killpg(proc.pid, signal.SIGKILL)

    def wait(self, proc, overflow, timeout):
        end = time.monotonic() + timeout
        while proc.poll() is None:
            self.monitor.check()
            require(not overflow.is_set(), "command stream32MiB limit")
            require(time.monotonic() < end, "command timeout")
            time.sleep(0.1)
        require(not overflow.is_set(), "command stream32MiB limit")

    def run(self, name, argv, timeout=300):
        self.monitor.check(force=True)
        self.serial += 1
        prefix = self.evidence / (str(self.serial).zfill(3) + "-" + name)
        proc = subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE, start_new_session=True)
        proc.owned_started = timestamp()
        proc.owned_pgid = os.getpgid(proc.pid)
        with self.active_lock:
            self.active.add(proc)
        state = {"overflow": threading.Event(), "done": set(), "errors": []}
        threads = [threading.Thread(target=collect, args=(stream, prefix.with_suffix(suffix), state, suffix))
                   for stream, suffix in [(proc.stdout, ".stdout"), (proc.stderr, ".stderr")]]
        for thread in threads:
            thread.start()
        failure = self.await_process(proc, state["overflow"], timeout)
        self.finish(proc, threads, prefix, argv, failure, state)
        if failure is not None:
            raise failure
        require(proc.returncode == 0, name + " failed; actual streams retained")
        return prefix

    def await_process(self, proc, overflow, timeout):
        try:
            self.wait(proc, overflow, timeout)
            return None
        except Exception as failure:
            try:
                self.cancel(proc)
            except Exception as stop_failure:
                return RuntimeError(str(failure) + "; owned stop failed: " + str(stop_failure))
            return failure

    def finish(self, proc, threads, prefix, argv, failure, state):
        code = proc.wait(timeout=30)
        with self.active_lock:
            self.active.discard(proc)
        for thread in threads:
            thread.join(timeout=30)
        drained = all(not thread.is_alive() for thread in threads) and len(state["done"]) == 2
        prefix.with_suffix(".exit").write_text(str(code) + "\n")
        save(prefix.with_suffix(".completion.json"), {"argv": argv, "exit_code": code,
             "pid": proc.pid, "process_group": proc.owned_pgid,
             "started_gst": proc.owned_started, "ended_gst": timestamp(),
             "drained": drained, "natural_exit": failure is None, "failure": str(failure),
             "collector_errors": state["errors"],
             "at_gst": timestamp()})
        require(drained, "full stdout/stderr drainage")


def kill_registered(proc):
    if proc.poll() is not None:
        return
    try:
        os.killpg(proc.pid, signal.SIGKILL)
    except ProcessLookupError:
        require(proc.poll() is not None, "registered live process group disappeared")
