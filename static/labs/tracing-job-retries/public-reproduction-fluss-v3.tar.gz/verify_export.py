"""Inspect real emitted archive independently and atomically return its receipt."""

import argparse
import os
from pathlib import Path
from guards import ancestors, fresh, require
from package_integrity import json_file, verify_package
from proof import digest, file_pin, save
from verification import inspect, read_archive


def verify(offer_path, manifest_sha, receipt_target):
    package = Path(__file__).absolute().parent
    verify_package(package, manifest_sha)
    offer = json_file(offer_path)
    fields = {"schema", "run_id", "manifest_sha256", "archive_sha256", "archive_bytes", "archive", "index_sha256", "nonce", "verifier_sha256", "projection_schema", "projection_sha256", "checker_sha256", "privacy_schema_sha256"}
    require(set(offer) == fields, "closed exchange offer")
    require(offer["schema"] == "fluss-export-offer-v2", "export offer schema")
    require(offer["manifest_sha256"] == manifest_sha, "externally pinned manifest")
    file_pin(Path(offer["archive"]), offer["archive_sha256"], offer["archive_bytes"])
    require(offer["verifier_sha256"] == digest(package / "verify_export.py"), "exact independent verifier pin")
    fresh(receipt_target)
    require(receipt_target == offer_path.parent / "receipt.json", "exact exchange receipt destination")
    data = read_archive(Path(offer["archive"]))
    checked = inspect(data, offer, package)
    file_pin(Path(offer["archive"]), offer["archive_sha256"], offer["archive_bytes"])
    fields = ("run_id", "archive_sha256", "archive_bytes", "manifest_sha256", "nonce", "index_sha256", "verifier_sha256", "projection_schema", "projection_sha256", "checker_sha256", "privacy_schema_sha256")
    receipt = {"schema": "fluss-export-receipt-v2", **{key: offer[key] for key in fields}, **checked}
    pending = receipt_target.with_suffix(".pending")
    fresh(pending)
    with pending.open("x") as stream:
        import json
        stream.write(json.dumps(receipt, indent=2, sort_keys=True) + "\n")
        stream.flush()
        os.fsync(stream.fileno())
    require(not receipt_target.exists(), "receipt target reused")
    os.rename(pending, receipt_target)
    return receipt


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--offer", type=Path, required=True)
    parser.add_argument("--manifest-sha256", required=True)
    parser.add_argument("--receipt-target", type=Path, required=True)
    args = parser.parse_args()
    print(verify(args.offer, args.manifest_sha256, args.receipt_target)["archive_sha256"])


if __name__ == "__main__":
    main()
