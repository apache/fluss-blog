"""Fixed ordinary-container stages on the reserved ext4 workspace."""

import argparse
import json
from pathlib import Path
import re
import socket
import shutil
import subprocess
import sys
import tarfile
import time

from guards import fresh, require
from proof import RELEASE_SHA512, RELEASE_SIZE, RELEASE_URL, build_binding, digest, result_binding, save, source_hashes
from placement import LAYOUT, container_paths

SOURCE = Path("/lab/source")
EVIDENCE = Path("/lab/evidence")
CLUSTER = Path("/lab/runtime/attempt-02/fluss-1.0.0")
MANIFEST = Path("/lab/staging/source-manifest.json")
TARGET = Path("/lab/runtime/build-target")
REPOSITORY = Path("/lab/runtime/m2")
BUILD_POM = Path("/lab/staging/build.pom.xml")


def command(argv, cwd=None, timeout=300):
    result = subprocess.run(argv, cwd=cwd, stdin=subprocess.DEVNULL, timeout=timeout)
    require(result.returncode == 0, "container command failed: " + repr(argv))


def version(argv):
    value = subprocess.run(argv, stdin=subprocess.DEVNULL, capture_output=True, timeout=30)
    sys.stdout.buffer.write(value.stdout)
    sys.stderr.buffer.write(value.stderr)
    require(value.returncode == 0, "actual version exit")
    return value.stdout.decode() + value.stderr.decode()


def versions():
    require('version "17.' in version(["java", "-version"]), "actual Java17")
    require(version(["javac", "-version"]).startswith("javac 17."), "actual compiler17")
    require("Apache Maven 3.9.9" in version(["mvn", "--version"]), "actual Maven3.9.9")
    require(sys.version_info[:3] == (3, 12, 3), "recorded container Python3.12.3")
    command(["python3", "-c", "import sqlite3; print(sqlite3.sqlite_version)"])


def archive():
    checked_workspace()
    path = Path("/lab/runtime/fluss-1.0.0-bin.tgz")
    fresh(path)
    command(["curl", "--fail", "--show-error", "--max-time", "600", "--output", str(path), RELEASE_URL], timeout=610)
    checksum = Path(str(path) + ".sha512")
    checked_workspace()
    command(["curl", "--fail", "--show-error", "--max-time", "60", "--output", str(checksum), RELEASE_URL + ".sha512"], timeout=70)
    values = re.findall(r"\b[0-9a-fA-F]{128}\b", checksum.read_text())
    require(len(values) == 1 and values[0].lower() == RELEASE_SHA512, "official SHA512 pinned")
    require(path.stat().st_size == RELEASE_SIZE, "recorded release size")
    require(digest(path, "sha512") == RELEASE_SHA512, "recorded release SHA512")
    save(EVIDENCE / "release-identity.json", {"url": RELEASE_URL, "sha512": RELEASE_SHA512,
         "bytes": path.stat().st_size, "observed_sha512": digest(path, "sha512")})
    extract_release(path)


def extract_release(path):
    checked_workspace()
    destination = Path("/lab/runtime/attempt-02")
    fresh(destination)
    with tarfile.open(path, "r:gz") as archive_file:
        for member in archive_file.getmembers():
            require(member.name.rstrip("/") == "fluss-1.0.0" or member.name.startswith("fluss-1.0.0/"), "supported release root")
            require(".." not in Path(member.name).parts, "release path traversal")
            require(not member.issym() and not member.islnk(), "release link forbidden")
        destination.mkdir()
        archive_file.extractall(destination)
    require((CLUSTER / "bin/local-cluster.sh").is_file(), "supported release startup layout")
    require((CLUSTER / "conf/server.yaml").is_file(), "supported release config layout")


def configure():
    checked_workspace()
    before, tested = EVIDENCE / "cluster-config-before", EVIDENCE / "cluster-config-tested"
    before.mkdir()
    tested.mkdir()
    for name in ("server.yaml", "zookeeper.properties"):
        (before / name).write_bytes((CLUSTER / "conf" / name).read_bytes())
    server = CLUSTER / "conf/server.yaml"
    value = server.read_text()
    for old, new in [("data.dir: /tmp/fluss-data", "data.dir: /lab/runtime/run-02-data"),
                     ("remote.data.dir: /tmp/fluss-remote-data", "remote.data.dir: /lab/runtime/attempt-02/remote-data")]:
        require(value.count(old) == 1, "exact default config: " + old)
        value = value.replace(old, new)
    require("disk.write" not in value and "disk-write" not in value, "default disk guard unchanged")
    server.write_text(value)
    zookeeper = CLUSTER / "conf/zookeeper.properties"
    value = zookeeper.read_text()
    require(value.count("dataDir=/tmp/zookeeper") == 1, "default ZooKeeper path")
    require("clientPortAddress=" not in value, "default ZooKeeper listener")
    zookeeper.write_text(value.replace("dataDir=/tmp/zookeeper", "dataDir=/lab/runtime/attempt-02/zookeeper-data")
                         + "\nclientPortAddress=127.0.0.1\n")
    for name in ("server.yaml", "zookeeper.properties"):
        (tested / name).write_bytes((CLUSTER / "conf" / name).read_bytes())


def prepare():
    checked_workspace()
    require(SOURCE.resolve() == SOURCE, "supported source layout /lab/source")
    source_hashes(SOURCE, MANIFEST)
    versions()
    archive()
    configure()


def build():
    checked_workspace()
    source_hashes(SOURCE, MANIFEST)
    versions()
    build_descriptor()
    command(maven("clean", "package"), cwd=SOURCE, timeout=1200)
    checked_workspace()
    build_binding(SOURCE, MANIFEST, EVIDENCE, TARGET)
    shutil.copyfile(TARGET / "fluss-retry-lab.jar", EVIDENCE / "tested.jar")
    shutil.copyfile(TARGET / "classes/lab/retry/FlussStore.class", EVIDENCE / "FlussStore.class")


def build_descriptor():
    source = (SOURCE / "pom.xml").read_text()
    require(source.count("<build>") == 1, "exact retained build block")
    paths = "<directory>/lab/runtime/build-target</directory><sourceDirectory>/lab/source/src/main/java</sourceDirectory>"
    text = source.replace("<build>", "<build>" + paths)
    fresh(BUILD_POM)
    BUILD_POM.write_text(text)
    shutil.copyfile(BUILD_POM, EVIDENCE / "build.pom.xml")


def maven(*goals):
    return ["mvn", "-B", "-f", str(BUILD_POM), "-Dmaven.repo.local=" + str(REPOSITORY), *goals]


def dependencies():
    checked_workspace()
    command(maven("dependency:tree"), cwd=SOURCE, timeout=300)
    checked_workspace()


def checked_workspace():
    layout = {**LAYOUT, "repository": str(REPOSITORY), "target": str(TARGET), "cluster": str(CLUSTER)}
    return container_paths(layout)


def ready():
    end = time.monotonic() + 45
    while time.monotonic() < end:
        try:
            with socket.create_connection(("127.0.0.1", 9123), timeout=1):
                return
        except OSError:
            time.sleep(1)
    raise TimeoutError("coordinator readiness45s")


def start():
    checked_workspace()
    command(["python3", str(SOURCE / "scripts/runtime_manifest.py"),
             "--archive", "/lab/runtime/fluss-1.0.0-bin.tgz", "--checksum", "/lab/runtime/fluss-1.0.0-bin.tgz.sha512",
             "--cluster", str(CLUSTER), "--evidence", str(EVIDENCE / "native-runtime")])
    command([str(CLUSTER / "bin/local-cluster.sh"), "start"], cwd=CLUSTER)
    ready()
    require((CLUSTER / "log").is_dir(), "supported native log layout")
    processes = version(["jps", "-l"])
    require(processes.count("CoordinatorServer") == 1, "one actual coordinator")
    require(processes.count("TabletServer") == 1, "one actual tablet")
    require(processes.count("QuorumPeerMain") == 1, "one actual ZooKeeper")
    save(EVIDENCE / "cluster-processes-before.json", cluster_processes(processes))
    command(["ss", "-ltnp"])
    actual_data_filesystem()
    command(["stat", "-c", "%s %b %n", "/lab/data4GiB.ext4"])


def verify(run_id):
    checked_workspace()
    binding = json.loads((EVIDENCE / "build-binding.json").read_text())
    require(digest(TARGET / "fluss-retry-lab.jar") == binding["jar_sha256"], "exact jar before test")
    command(["python3", str(SOURCE / "scripts/e2e.py"), "verify", "--run-id", run_id,
             "--evidence", str(EVIDENCE / "e2e"), "--cluster-evidence", str(EVIDENCE / "native-runtime/cluster-runtime.json"),
             "--service-port", "18080", "--bootstrap", "localhost:9123", "--jar", str(TARGET / "fluss-retry-lab.jar"), "--timeout", "60"],
            cwd=SOURCE, timeout=600)
    result = result_binding(EVIDENCE / "e2e", SOURCE, MANIFEST, binding, run_id, TARGET)
    before = json.loads((EVIDENCE / "cluster-processes-before.json").read_text())
    after = cluster_processes(version(["jps", "-l"]))
    require(before == after, "separate Fluss cluster survived all worker kills")
    save(EVIDENCE / "cluster-processes-after.json", after)
    save(EVIDENCE / "observed-result.json", result)


def cluster_processes(text):
    return sorted(line for line in text.splitlines()
                  if any(name in line for name in ("CoordinatorServer", "TabletServer", "QuorumPeerMain")))


def actual_data_filesystem():
    text = version(["df", "-B1", "--output=fstype,target,size,avail,pcent", "/lab/runtime/run-02-data"])
    fields = text.splitlines()[1].split()
    require(fields[0] == "ext4", "actual container data.dir filesystem ext4")
    require(fields[1] == "/lab/runtime", "actual container workspace mount target")
    require(3.5 * 1073741824 <= int(fields[2]) <= 4 * 1073741824, "actual4GiB data filesystem capacity")
    require(int(fields[4].rstrip("%")) < 85, "actual data filesystem write guard")
    save(EVIDENCE / "actual-data-filesystem.json", {"raw_df": text, "fstype": fields[0], "target": fields[1],
         "capacity_bytes": int(fields[2]), "available_bytes": int(fields[3]), "used_percent": int(fields[4].rstrip("%"))})


def stop():
    checked_workspace()
    command([str(CLUSTER / "bin/local-cluster.sh"), "stop"], cwd=CLUSTER, timeout=60)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stage", choices=["prepare", "build", "dependencies", "start", "verify", "stop"])
    parser.add_argument("--run-id", required=True)
    args = parser.parse_args()
    actions = {"prepare": prepare, "build": build, "dependencies": dependencies, "start": start, "stop": stop}
    if args.stage == "verify":
        verify(args.run_id)
    else:
        actions[args.stage]()


if __name__ == "__main__":
    main()
