"""Private raw observation contract; these records never enter the public export."""

import json
from pathlib import Path
from types import SimpleNamespace
from guards import GIB, SCOPE, require
from proof import IMAGE, RELEASE_URL, RELEASE_SIZE, RELEASE_SHA512, verify_workers, verify_service, verify_jar_commands
from supervision import check_sample

from placement import filesystem_record
from stages import container_argv, STAGES
from public_run import ABSENCE_SCRIPT

CASES = {"baseline", "repeat-compute", "before-http", "after-commit", "unknown", "duplicate-event", "conflicting-action"}




def obj(data, name):
    return json.loads(data["evidence/" + name])










def inspect_result(data, binding, run_id):
    observed = obj(data, "e2e/manifest.json")
    assertions = obj(data, "e2e/assertions.json")
    commands = obj(data, "e2e/commands.json")
    require(observed["run_id"] == run_id and observed["status"] == "PASSED", "actual workload identity/result")
    require(observed["error"] is None and observed["cleanup_errors"] == [], "actual workload cleanup/error")
    require(observed["cases_started"] == observed["specified_cases"] == 7, "all seven raw cases")
    require(set(observed["case_status"]) == CASES, "exact seven case identities")
    require(len(assertions) == observed["assertion_count"] == 234, "all234 raw assertions")
    require(all(row["passed"] is True and row["expected"] == row["observed"] for row in assertions), "raw assertion equality")
    verify_workers(commands, observed)
    verify_service(commands)
    verify_jar_commands(commands, binding["jar_path_tested"], run_id)
    inspect_worker_streams(data, commands)


def inspect_worker_streams(data, commands):
    require(bool(commands), "raw worker process records")
    for row in commands:
        require(row["pid"] > 0 and row["ended_gst"] >= row["started_gst"], "worker PID/timing provenance")
        require(type(row["exit_code"]) is int, "actual integer worker exit")
        prefix = Path(row["prefix"]).name
        for suffix in (".stdout.log", ".stderr.log"):
            require("evidence/e2e/" + prefix + suffix in data, "raw worker stream missing")
    inspect_recovery_jobs(commands)


def recovery_for(row, job):
    if "--job" not in row["argv"]:
        return False
    return row["argv"][row["argv"].index("--job") + 1] == job


def inspect_recovery_jobs(commands):
    killed = [row for row in commands if row["exit_code"] == -9]
    recovered = [row for row in commands if row["name"].startswith("recover-")]
    for row in killed:
        job = row["argv"][row["argv"].index("--job") + 1]
        require(any(recovery_for(value, job)
                    and value["pid"] != row["pid"] for value in recovered), "exact killed/recovery job identity")


def inspect_phases(data):
    records = {}
    for name in data:
        if name.startswith("evidence/") and name.endswith(".completion.json"):
            row = json.loads(data[name])
            require(row["exit_code"] == 0 and row["natural_exit"] is True and row["drained"] is True, "actual phase exit/drain")
            require(row["failure"] == "None" and row["collector_errors"] == [], "phase failure/collector provenance")
            require(row["pid"] > 0 and row["process_group"] == row["pid"], "registered actual phase process group")
            require(row["ended_gst"] >= row["started_gst"], "phase start/end provenance")
            prefix = name.removesuffix(".completion.json")
            require(data[prefix + ".exit"].strip() == b"0", "actual phase exit stream")
            require(prefix + ".stdout" in data and prefix + ".stderr" in data, "actual phase streams")
            key = Path(prefix).name[4:]
            require(key not in records, "unique phase record")
            records[key] = row
    required = {"allocate4GiB", "format-nodiscard", "attach-loop", "mount-owned", "network-create", "pull-pinned-image",
                "container-create", "container-apt-update", "container-packages", "prepare", "build", "dependencies", "start", "verify", "stop",
                "remove-owned-container", "remove-owned-network", "sync-owned-data", "unmount-owned", "detach-owned-loop"}
    require(required <= set(records), "complete bootstrap/workload/cleanup phase records")
    return records


def inspect_runtime(data):
    release = obj(data, "release-identity.json")
    require(release == {"url": RELEASE_URL, "sha512": RELEASE_SHA512, "bytes": RELEASE_SIZE,
                        "observed_sha512": RELEASE_SHA512}, "exact observed release provenance")
    before = obj(data, "cluster-processes-before.json")
    require(before == obj(data, "cluster-processes-after.json") and len(before) == 3, "three surviving Fluss services")
    require(all(any(kind in row for row in before) for kind in ("CoordinatorServer", "TabletServer", "QuorumPeerMain")), "exact service identities")
    storage = obj(data, "storage-identity.json")
    require(storage["size"] == 4 * GIB and storage["allocated_bytes"] >= 4 * GIB, "physical4GiB reservation")
    require(storage["format"] == "mkfs.ext4 -m0 -E nodiscard", "unchanged nondiscard format")
    for phase in ("packages", "prepare", "build", "dependencies", "start", "verify", "stop"):
        record = obj(data, "workspace-" + phase + ".json")
        require(record == filesystem_record(record["raw_df"], storage["loop"]), "actual workspace capacity/identity/guard")
        require(phase_stdout(data, "workspace-" + phase) == record["raw_df"].strip(), "raw recorded filesystem observation")
        layer = json.loads(phase_stdout(data, "layer-" + phase))
        require(layer["Id"] == obj(data, "container-identity.json")["Id"], "raw inspected writable layer identity")
        budget = obj(data, "operator-inputs.json")["outside_budget"]["limits"]["docker_writable_bytes"]
        require(layer["SizeRw"] <= budget, "raw writable layer budget")
    inspect_config(data)
    inspect_container(data)


def inspect_container(data):
    container = obj(data, "container-identity.json")
    image = obj(data, "image-identity.json")
    config = container["HostConfig"]
    require(container["Image"] == image["Id"], "actual pinned image ID")
    require(IMAGE.removeprefix("docker.io/library/") in image["RepoDigests"], "exact image digest")
    require(image["Os"] == "linux" and image["Architecture"] == "amd64", "actual native image")
    require(not config["Privileged"] and not config["CapAdd"] and not config["PortBindings"], "actual ordinary container")
    require(config["Memory"] == config["MemorySwap"] == 8 * GIB, "actual memory/swap limit")
    require(config["NanoCpus"] == 3000000000 and config["PidsLimit"] == 1024, "actual CPU/PID limit")
    require(config["LogConfig"] == {"Type": "json-file", "Config": {"max-size": "4m", "max-file": "2"}}, "actual log limits")
    root = str(Path(obj(data, "storage-identity.json")["image"]).parent)
    mounts = {row["Destination"]: row["Source"] for row in container["Mounts"]}
    require(mounts == {"/lab": root, "/lab/source": root + "/source", "/lab/runtime": obj(data, "storage-identity.json")["mount"]}, "actual reserved workspace binding")


def inspect_config(data):
    before = data["evidence/cluster-config-before/server.yaml"].decode()
    expected = before.replace("data.dir: /tmp/fluss-data", "data.dir: /lab/runtime/run-02-data")
    expected = expected.replace("remote.data.dir: /tmp/fluss-remote-data", "remote.data.dir: /lab/runtime/attempt-02/remote-data")
    require(expected == data["evidence/cluster-config-tested/server.yaml"].decode(), "unchanged default Fluss write guard/config")
    before = data["evidence/cluster-config-before/zookeeper.properties"].decode()
    expected = before.replace("dataDir=/tmp/zookeeper", "dataDir=/lab/runtime/attempt-02/zookeeper-data") + "\nclientPortAddress=127.0.0.1\n"
    require(expected == data["evidence/cluster-config-tested/zookeeper.properties"].decode(), "exact ZooKeeper placement")


def inspect_cleanup(data, phases):
    cleanup = obj(data, "cleanup-observations.json")
    container = obj(data, "container-identity.json")
    storage = obj(data, "storage-identity.json")
    require(cleanup["container_id"] == container["Id"] and cleanup["loop"] == storage["loop"], "exact cleaned identities")
    require(cleanup["image"] == storage["image"] and cleanup["image_identity"] == storage["image_identity"], "exact cleaned inode")
    require(cleanup["container_id"] not in cleanup["remaining_container_ids"], "owned container actually absent")
    require(cleanup["network_id"] not in cleanup["remaining_network_ids"], "owned network actually absent")
    require(storage["mount"] not in cleanup["remaining_mounts"] and cleanup["image_exists"] is False, "mount/file actually absent")
    require(cleanup["remaining_image_loops"] == "", "owned loop actually detached")
    inspect_created_identities(data, cleanup, storage)
    require(phases["remove-owned-container"]["argv"] == ["docker", "rm", cleanup["container_id"]], "recorded exact container removal")
    require(phases["remove-owned-network"]["argv"] == ["docker", "network", "rm", cleanup["network_id"]], "recorded exact network removal")
    require(phases["unmount-owned"]["argv"] == ["umount", "--", storage["mount"]], "recorded exact unmount")
    require(phases["detach-owned-loop"]["argv"] == ["losetup", "-d", storage["loop"]], "recorded exact detach")
    require(obj(data, "unrelated-before.json") == obj(data, "unrelated-after.json"), "actual current foreign preservation")
    inspect_absence_queries(data, phases, cleanup)


def inspect_created_identities(data, cleanup, storage):
    require(phase_stdout(data, "attach-loop") == storage["loop"], "raw created loop identity")
    require(phase_stdout(data, "container-create") == cleanup["container_id"], "raw created container identity")
    require(phase_stdout(data, "network-create") == cleanup["network_id"], "raw created network identity")
    network = obj(data, "network-identity.json")
    require(network["Id"] == cleanup["network_id"], "raw positively owned network ID")
    run_id = obj(data, "operator-inputs.json")["run_id"]
    require(network["Labels"]["fluss-guarded-owner"] == run_id, "raw network owner label")
    require(set(network["Containers"]) <= {cleanup["container_id"]}, "raw exact network borrower set")


def phase_stdout(data, name):
    names = [key for key in data if key.startswith("evidence/") and Path(key).name[4:] == name + ".stdout"]
    require(len(names) == 1, "single actual observation stream")
    return data[names[0]].decode().strip()


def inspect_absence_queries(data, phases, cleanup):
    queries = {"containers": (["docker", "ps", "-aq", "--no-trunc"], "remaining_container_ids"),
               "networks": (["docker", "network", "ls", "-q", "--no-trunc"], "remaining_network_ids"),
               "mounts": (["findmnt", "-rn", "-o", "TARGET"], "remaining_mounts")}
    for name, (argv, field) in queries.items():
        key = "observe-cleanup-" + name
        require(phases[key]["argv"] == argv, "exact cleanup observation argv")
        require(phase_stdout(data, key).splitlines() == cleanup[field], "raw cleanup observation equality")
    key = "observe-cleanup-loops"
    require(phases[key]["argv"] == ["losetup", "-j", cleanup["image"]], "exact loop absence query")
    require(phase_stdout(data, key) == cleanup["remaining_image_loops"] == "", "raw loop absence")
    key = "observe-cleanup-file"
    require(phases[key]["argv"] == ["/usr/bin/python3", "-B", "-c", ABSENCE_SCRIPT, cleanup["image"]], "exact file lstat query")
    require(json.loads(phase_stdout(data, key)) == cleanup["file_lstat"] == {"path": cleanup["image"], "errno": 2}, "raw ENOENT; no summary pass credit")


def inspect_phase_contract(data, phases, offer):
    storage = obj(data, "storage-identity.json")
    owned = SimpleNamespace(name=offer["run_id"], manifest=offer["manifest_sha256"], root=Path(storage["image"]).parent,
                            image=Path(storage["image"]), mount=Path(storage["mount"]), loop=storage["loop"])
    expected = {"allocate4GiB": ["fallocate", "-l", "4G", str(owned.image)],
                "format-nodiscard": ["/usr/sbin/mkfs.ext4", "-m", "0", "-E", "nodiscard", str(owned.image)],
                "attach-loop": ["losetup", "--find", "--show", str(owned.image)],
                "mount-owned": ["mount", "-t", "ext4", "-o", "nosuid,nodev", owned.loop, str(owned.mount)],
                "network-create": ["docker", "network", "create", "--label", "fluss-guarded-owner=" + owned.name, owned.name],
                "pull-pinned-image": ["docker", "pull", "--platform", "linux/amd64", IMAGE], "container-create": container_argv(owned),
                "container-apt-update": ["docker", "exec", owned.name, "apt-get", "update"],
                "container-packages": ["docker", "exec", "--env", "DEBIAN_FRONTEND=noninteractive", owned.name,
                                      "apt-get", "install", "-y", "--no-install-recommends", "python3", "procps", "iproute2"]}
    for name, timeout in STAGES:
        expected[name] = ["docker", "exec", "--env", "PYTHONDONTWRITEBYTECODE=1", owned.name,
                          "python3", "/lab/staging/inside.py", name, "--run-id", owned.name]
    for name, argv in expected.items():
        require(phases[name]["argv"] == argv, "exact bootstrap/workload argv: " + name)
    ordered = [Path(name).name[4:].removesuffix(".completion.json") for name in sorted(data)
               if name.startswith("evidence/") and name.endswith(".completion.json")]
    require([name for name in ordered if name in expected] == list(expected), "fixed bootstrap/workload phase order")


def inspect_monitor(data):
    frozen = obj(data, "export-monitor.json")
    require(frozen["thread_alive"] is True and frozen["error"] == "None", "original monitor active at export")
    rows = [json.loads(line) for line in data["evidence/host-monitor-export.jsonl"].splitlines()]
    require(len(rows) >= 2, "preallocation through cleanup samples")
    peak = frozen["baseline"]
    for row in rows:
        check_sample(row, preboot=row["preboot"])
        require(row["peak_used_bytes"] >= max(peak, row["used_bytes"]), "monotonic cumulative peak")
        require(row["growth_bytes"] == max(0, row["peak_used_bytes"] - frozen["baseline"]), "original baseline growth")
        peak = row["peak_used_bytes"]
    require(rows[0]["preboot"] is True and peak == frozen["peak"], "preallocation baseline and full frozen peak")


