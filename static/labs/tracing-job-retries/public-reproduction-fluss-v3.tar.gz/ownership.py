"""Exact task inode, loop, container and network ownership; never prune images."""

import json
import os
from pathlib import Path
import stat
import subprocess

from guards import allocation, ancestors, borrowers, fresh, mount_identity, require
from proof import IMAGE, save
from supervision import output


def containers():
    identities = output(["docker", "ps", "-aq"]).split()
    require(len(identities) <= 256, "bounded container inventory")
    if not identities:
        return []
    return json.loads(output(["docker", "inspect", *identities]))


class Owned:
    def __init__(self, run_id, manifest, root):
        self.name = run_id
        self.manifest = manifest
        self.root = Path(root)
        self.evidence = self.root / "evidence"
        self.image = self.root / "data4GiB.ext4"
        self.mount = self.root / "data-mount"
        self.loop = None
        self.container_id = None
        self.network_id = None
        self.inode = None
        self.device = None
        self.image_identity = None
        self.layer_monitoring = False

    def persist(self):
        save(self.root / "owned-state.json", {"run_id": self.name, "manifest_sha256": self.manifest,
             "root_device": self.device, "root_inode": self.inode, "image_identity": self.image_identity,
             "container_id": self.container_id, "network_id": self.network_id, "loop": self.loop})

    def load(self):
        state = json.loads((self.root / "owned-state.json").read_text())
        require(state["run_id"] == self.name and state["manifest_sha256"] == self.manifest, "exact saved owned state")
        self.device, self.inode = state["root_device"], state["root_inode"]
        self.container_id, self.network_id, self.loop = state["container_id"], state["network_id"], state["loop"]
        if state["image_identity"] is not None:
            self.image_identity = tuple(state["image_identity"])
        self.root_identity()

    def create_root(self):
        fresh(self.root)
        self.root.mkdir(mode=0o700)
        for name in ("source", "evidence", "staging", "runtime"):
            (self.root / name).mkdir(mode=0o700)
        self.device, self.inode = self.root.stat().st_dev, self.root.stat().st_ino
        save(self.root / "ownership.json", {"run_id": self.name, "manifest_sha256": self.manifest,
             "root_device": self.device, "root_inode": self.inode})
        self.persist()

    def root_identity(self):
        ancestors(self.root)
        require((self.root.stat().st_dev, self.root.stat().st_ino) == (self.device, self.inode), "owned root inode")
        receipt = json.loads((self.root / "ownership.json").read_text())
        require(receipt["run_id"] == self.name and receipt["manifest_sha256"] == self.manifest, "owned root marker")

    def create_image(self):
        self.root_identity()
        fresh(self.image)
        descriptor = os.open(self.image, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
        os.close(descriptor)
        self.image_identity = (self.image.stat().st_dev, self.image.stat().st_ino)
        self.persist()
        fresh(self.mount)
        self.mount.mkdir(mode=0o700)

    def check_image(self, physical=True):
        self.root_identity()
        ancestors(self.image)
        info = self.image.stat()
        require(stat.S_ISREG(info.st_mode), "owned regular image")
        require((info.st_dev, info.st_ino) == self.image_identity, "exact owned image inode")
        require(info.st_uid == os.geteuid() and info.st_nlink == 1, "owned image uid/hardlink")
        if physical:
            allocation(info.st_size, info.st_blocks, info.st_nlink)

    def check_mount(self):
        self.check_image()
        ancestors(self.mount)
        value = json.loads(output(["findmnt", "-J", "-M", str(self.mount), "-o", "SOURCE,TARGET,FSTYPE,OPTIONS"]))
        require(len(value["filesystems"]) == 1, "single own mount")
        backing = output(["losetup", "-n", "-O", "BACK-FILE", self.loop]).strip()
        mount_identity(value["filesystems"][0], self.loop, self.mount, self.image, backing)
        loops = output(["losetup", "-j", str(self.image)]).splitlines()
        require(len(loops) == 1 and loops[0].startswith(self.loop + ":"), "single owned loop")
        targets = output(["findmnt", "-rn", "-S", self.loop, "-o", "TARGET"]).splitlines()
        require(targets == [str(self.mount)], "no additional host mount borrower")

    def no_host_process_borrowers(self):
        result = subprocess.run(["fuser", "-m", str(self.mount)], stdin=subprocess.DEVNULL,
                                capture_output=True, timeout=30)
        require(result.returncode == 1 and not result.stdout.strip(), "host mount process borrower")

    def no_file_process_borrowers(self):
        result = subprocess.run(["fuser", str(self.image)], stdin=subprocess.DEVNULL,
                                capture_output=True, timeout=30)
        require(result.returncode == 1 and not result.stdout.strip(), "owned image process borrower")

    def inspect(self):
        items = containers()
        matching = [item for item in items if item["Name"] == "/" + self.name]
        if not matching:
            require(self.container_id is None, "owned container disappeared")
            return None
        require(len(matching) == 1, "exact owned container name")
        value = matching[0]
        require(value["Config"]["Labels"].get("fluss-guarded-owner") == self.name, "positive container owner")
        require(value["Config"]["Labels"].get("fluss-proposal") == self.manifest, "container proposal binding")
        if self.container_id is not None:
            require(value["Id"] == self.container_id, "exact container ID")
        return value

    def verify_container(self):
        value = self.inspect()
        require(value is not None, "owned container exists")
        config = value["HostConfig"]
        require(not config["Privileged"] and not config["CapAdd"] and not config["PortBindings"], "ordinary container")
        require(config["LogConfig"] == {"Type": "json-file", "Config": {"max-size": "4m", "max-file": "2"}}, "task-only bounded logging")
        require(config["Memory"] == 8 * 1073741824 and config["MemorySwap"] == 8 * 1073741824, "container memory")
        require(config["NanoCpus"] == 3000000000 and config["PidsLimit"] == 1024, "container CPU/PID")
        mounts = {item["Destination"]: item["Source"] for item in value["Mounts"]}
        require(mounts == {"/lab": str(self.root), "/lab/source": str(self.root / "source"),
                          "/lab/runtime": str(self.mount)}, "exact /lab/source and ext4 binds")
        image = json.loads(output(["docker", "image", "inspect", IMAGE]))[0]
        require(value["Image"] == image["Id"], "actual image ID")
        require(IMAGE.removeprefix("docker.io/library/") in image["RepoDigests"], "pinned image canonical repo digest")
        require(image["Os"] == "linux" and image["Architecture"] == "amd64", "native image platform")
        save(self.evidence / "container-identity.json", value)
        save(self.evidence / "image-identity.json", image)

    def stop(self):
        value = self.inspect()
        if value is None:
            return
        if value["State"]["Running"]:
            output(["docker", "stop", "--time", "5", value["Id"]], timeout=30)
        require(not self.inspect()["State"]["Running"], "owned container must stop before diagnostics")

    def no_borrowers(self):
        borrowers(containers(), self.container_id, self.name, str(self.root), self.loop)
        if self.network_id is None:
            return
        network = json.loads(output(["docker", "network", "inspect", self.network_id]))[0]
        require(network["Id"] == self.network_id, "exact network ID")
        require(network["Labels"].get("fluss-guarded-owner") == self.name, "network owner")
        require(set(network["Containers"]) <= {self.container_id}, "network borrower")
        save(self.evidence / "network-identity.json", network)

    def remove_container(self, recorder):
        if self.container_id is None:
            return
        self.inspect()
        self.layer_monitoring = False
        recorder.run("remove-owned-container", ["docker", "rm", self.container_id], 30)
        self.container_id = None
        self.persist()

    def remove_network(self, recorder):
        if self.network_id is None:
            return
        self.no_borrowers()
        recorder.run("remove-owned-network", ["docker", "network", "rm", self.network_id], 30)
        self.network_id = None
        self.persist()

    def cleanup(self, recorder):
        self.stop()
        self.root_identity()
        self.no_borrowers()
        self.check_mount()
        self.no_host_process_borrowers()
        self.remove_container(recorder)
        self.remove_network(recorder)
        self.check_mount()
        self.no_host_process_borrowers()
        recorder.run("sync-owned-data", ["sync", "-f", str(self.mount)], 30)
        self.no_borrowers()
        self.check_mount()
        self.no_host_process_borrowers()
        recorder.run("unmount-owned", ["umount", "--", str(self.mount)], 30)
        remaining = output(["findmnt", "-rn", "-o", "TARGET"]).splitlines()
        require(str(self.mount) not in remaining, "own mount removed")
        self.check_image()
        require(output(["losetup", "-n", "-O", "BACK-FILE", self.loop]).strip() == str(self.image), "backing file before detach")
        recorder.run("detach-owned-loop", ["losetup", "-d", self.loop], 30)
        require(not output(["losetup", "-j", str(self.image)]).strip(), "own loop detached")
        self.loop = None
        self.persist()
        self.check_image()
        self.no_borrowers()
        self.no_file_process_borrowers()
        recorder.monitor.check(force=True)
        self.image.unlink()
        self.image_identity = None
        self.persist()
        save(self.evidence / "cleanup.json", {"owned_container_removed": True, "owned_network_removed": True,
             "owned_mount_unmounted": True, "owned_loop_detached": True, "owned_4GiB_file_removed": True,
             "source_evidence_staging_retained": True, "docker_images_retained_and_charged_to_first_baseline": True})
