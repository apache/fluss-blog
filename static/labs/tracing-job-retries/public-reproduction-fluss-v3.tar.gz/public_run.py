"""Complete neutral guarded lifecycle; external authorization is required."""

import argparse
import json
import os
from pathlib import Path
import signal
import time
from boundaries import boundary, equal_foreign, foreign, foreign_hash, live
from configuration import authorize, provenance, reference, reserve_budget, validate_config
from exchange import wait_receipt
from export import seal
from guards import require
from host import fresh_slot, primary
from ownership import Owned
from package_integrity import json_file, verify_package
from proof import digest, save
from stages import STAGES, boot, collect_native_logs, packages, seed, storage, workload_stage
from supervision import Monitor, Recorder, check_sample, host_sample, output, timestamp

ABSENCE_SCRIPT = "import os,sys,json\ntry:\n os.lstat(sys.argv[1])\nexcept FileNotFoundError as error:\n print(json.dumps({'path':sys.argv[1],'errno':error.errno}))\nelse:\n raise RuntimeError('owned file still exists')"


def inputs(args):
    package = Path(__file__).absolute().parent
    verify_package(package, args.manifest_sha256)
    config = validate_config(json_file(args.operator_config), args.exchange_dir)
    observed = primary(config, args.exchange_dir)
    fresh_slot(config["run_id"])
    before = foreign()
    authorize(json_file(args.operator_authorization), config, args.manifest_sha256, foreign_hash(before))
    initial = host_sample(Path(config["root"]).parent, 0, 0)
    baseline, peak, history = provenance(config["baseline"], initial, observed["device"])
    sample = host_sample(Path(config["root"]).parent, baseline, peak)
    check_sample(sample, preboot=True)
    reserve_budget(sample, baseline, config)
    return package, config, observed, before, baseline, max(peak, sample["used_bytes"]), history, sample


def execute(args):
    package, config, observed, before, baseline, peak, history, sample = inputs(args)
    owned = Owned(config["run_id"], args.manifest_sha256, config["root"])
    monitor = Monitor(owned, baseline, peak, time.monotonic() + 3600)
    monitor.maximum_used = sample["used_bytes"] + 4 * 1073741824 + config["outside_total_bytes"]
    recorder = Recorder(owned.evidence, monitor)
    monitor.sample(preboot=True)
    monitor.thread.start()
    previous = install_cancellation(monitor)
    try:
        initialize(package, config, observed, before, history, owned, monitor, args.exchange_dir)
        lifecycle(package, config, owned, recorder, before, args.exchange_dir)
    except BaseException as failure:
        fail(owned, monitor, failure)
        raise
    finally:
        close(owned, monitor, previous)


def install_cancellation(monitor):
    def cancel(signum, frame):
        monitor.trip(RuntimeError("operator cancellation signal " + str(signum)))
        raise InterruptedError("operator cancelled guarded lifecycle")
    previous = {signum: signal.getsignal(signum) for signum in (signal.SIGINT, signal.SIGTERM)}
    for signum in previous:
        signal.signal(signum, cancel)
    return previous


def initialize(package, config, observed, before, history, owned, monitor, exchange):
    live(monitor)
    equal_foreign(before, foreign())
    owned.budget = config["outside_budget"]["limits"]
    owned.create_root()
    exchange.mkdir(mode=0o700)
    save(owned.evidence / "preflight.json", observed)
    save(owned.evidence / "operator-inputs.json", config)
    save(owned.evidence / "budget-provenance.json", reference(config["outside_budget"]["provenance"]))
    save(owned.evidence / "baseline-provenance.json", history)
    save(owned.evidence / "unrelated-before.json", before)
    seed(package, owned)
    monitor.sample(preboot=True)


def lifecycle(package, config, owned, recorder, before, exchange):
    monitor = recorder.monitor
    boundary(owned, monitor, before, "allocation")
    reserve_budget(monitor.sample(preboot=True), monitor.baseline, config)
    storage(owned, recorder)
    boundary(owned, monitor, before, "boot")
    boot(owned, recorder, config["outside_budget"]["limits"])
    boundary(owned, monitor, before, "packages")
    packages(owned, recorder)
    for name, timeout in STAGES:
        boundary(owned, monitor, before, name)
        workload_stage(owned, recorder, name, timeout)
    boundary(owned, monitor, before, "cleanup")
    collect_native_logs(owned, monitor)
    cleanup(owned, recorder, before)
    boundary(owned, monitor, before, "export")
    offer = seal(package, owned, monitor, exchange)
    receipt = wait_receipt(owned, monitor, before, exchange, offer)
    boundary(owned, monitor, before, "complete")
    save(owned.evidence / "returned-receipt.json", receipt)
    save(owned.evidence / "lifecycle-result.json", {"run_id": owned.name, "archive_sha256": offer["archive_sha256"],
         "receipt_sha256": digest(exchange / "receipt.json"), "monitor_alive_at_receipt": monitor.thread.is_alive(),
         "baseline": monitor.baseline, "peak": monitor.peak, "at_gst": timestamp()})


def read_cleanup(recorder, name, argv):
    prefix = recorder.run("observe-cleanup-" + name, argv, 30)
    return prefix.with_suffix(".stdout").read_text().strip()


def cleanup(owned, recorder, before):
    identities = {"container_id": owned.container_id, "network_id": owned.network_id,
                  "loop": owned.loop, "image": str(owned.image), "image_identity": list(owned.image_identity)}
    owned.cleanup(recorder)
    observed = {**identities,
                "remaining_container_ids": read_cleanup(recorder, "containers", ["docker", "ps", "-aq", "--no-trunc"]).splitlines(),
                "remaining_network_ids": read_cleanup(recorder, "networks", ["docker", "network", "ls", "-q", "--no-trunc"]).splitlines(),
                "remaining_mounts": read_cleanup(recorder, "mounts", ["findmnt", "-rn", "-o", "TARGET"]).splitlines(),
                "remaining_image_loops": read_cleanup(recorder, "loops", ["losetup", "-j", str(owned.image)]),
                "file_lstat": json.loads(read_cleanup(recorder, "file", ["/usr/bin/python3", "-B", "-c", ABSENCE_SCRIPT, str(owned.image)])),
                "image_exists": owned.image.exists()}
    require(observed["file_lstat"] == {"path": str(owned.image), "errno": 2}, "actual file ENOENT")
    require(identities["container_id"] not in observed["remaining_container_ids"], "exact container removed")
    require(identities["network_id"] not in observed["remaining_network_ids"], "exact network removed")
    require(str(owned.mount) not in observed["remaining_mounts"], "exact mount absent")
    require(observed["remaining_image_loops"] == "" and observed["image_exists"] is False, "exact loop/file absent")
    after = foreign()
    equal_foreign(before, after)
    save(owned.evidence / "unrelated-after.json", after)
    save(owned.evidence / "cleanup-observations.json", observed)


def fail(owned, monitor, failure):
    monitor.error = failure
    monitor.cancel_owned()
    if owned.evidence.is_dir():
        save(owned.evidence / "actual-failure.json", {"error": str(failure), "at_gst": timestamp(),
             "automatic_destructive_teardown": False, "owned_residue_retained_for_operator_review": True})


def close(owned, monitor, previous):
    monitor.close()
    for signum, handler in previous.items():
        signal.signal(signum, handler)
    if owned.evidence.is_dir():
        save(owned.evidence / "lifecycle.completion.json", {"error": str(monitor.error),
             "monitor_drained": not monitor.thread.is_alive(), "at_gst": timestamp(),
             "returned_receipt_present": (owned.evidence / "returned-receipt.json").is_file()})
    require(monitor.error is None, "guarded lifecycle failed: " + str(monitor.error))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest-sha256", required=True)
    parser.add_argument("--operator-config", type=Path, required=True)
    parser.add_argument("--operator-authorization", type=Path, required=True)
    parser.add_argument("--exchange-dir", type=Path, required=True)
    execute(parser.parse_args())


if __name__ == "__main__":
    main()
