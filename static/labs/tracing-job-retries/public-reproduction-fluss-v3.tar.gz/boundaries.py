"""Current foreign resources and live supervision at each mutation boundary."""

import hashlib
import json
from guards import require
from ownership import containers
from proof import save


def foreign(own_id=None):
    return {row["Id"]: {"name": row["Name"], "image": row["Image"], "running": row["State"]["Running"],
            "started": row["State"]["StartedAt"], "mounts": row["Mounts"],
            "host_config": row["HostConfig"], "labels": row["Config"].get("Labels")}
            for row in containers() if row["Id"] != own_id}


def foreign_hash(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def equal_foreign(before, after):
    require(before == after, "CURRENT foreign container identities/state/mounts changed")


def live(monitor):
    if monitor.error is not None:
        raise RuntimeError("guard/cancellation failure: " + str(monitor.error))
    if not monitor.thread.is_alive():
        raise RuntimeError("continuous monitor not alive")
    monitor.check(force=True)


def boundary(owned, monitor, before, name):
    live(monitor)
    after = foreign(owned.container_id)
    equal_foreign(before, after)
    save(owned.evidence / ("boundary-" + name + ".json"), after)
