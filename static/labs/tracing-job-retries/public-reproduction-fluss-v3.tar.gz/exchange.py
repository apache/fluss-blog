"""Bound returned independent receipt while the original monitor stays active."""

import time
from boundaries import boundary
from guards import require
from package_integrity import json_file
from proof import digest


def expected_checks(owned):
    require(hasattr(owned, "export_checks"), "actual exported projection checks required")
    return owned.export_checks


def check_receipt(receipt, offer, expected):
    fields = ("run_id", "archive_sha256", "archive_bytes", "manifest_sha256", "nonce", "index_sha256", "verifier_sha256", "projection_schema", "projection_sha256", "checker_sha256", "privacy_schema_sha256")
    require(receipt["schema"] == "fluss-export-receipt-v2", "independent receipt schema")
    require(set(receipt) == set(fields) | {"schema"} | set(expected), "exact independent receipt fields")
    for field in fields:
        require(receipt[field] == offer[field], "receipt binding: " + field)
    for field, value in expected.items():
        require(receipt[field] == value, "receipt checked actual provenance: " + field)


def wait_receipt(owned, monitor, before, exchange, offer):
    end = min(time.monotonic() + 300, monitor.deadline)
    target = exchange / "receipt.json"
    while not target.exists():
        boundary(owned, monitor, before, "receipt-wait")
        require(time.monotonic() < end, "independent export receipt timeout300s")
        time.sleep(1)
    boundary(owned, monitor, before, "receipt-return")
    require(time.monotonic() < end, "late independent receipt")
    receipt = json_file(target)
    check_receipt(receipt, offer, expected_checks(owned))
    return receipt
