"""Container namespace workspace probe using externally bound loop identity."""

import json
from placement import container_paths


def main():
    print(json.dumps(container_paths(), sort_keys=True))


if __name__ == "__main__":
    main()
