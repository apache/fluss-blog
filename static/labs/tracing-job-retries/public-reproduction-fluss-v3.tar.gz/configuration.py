"""External operator inputs and immutable baseline provenance."""

from datetime import datetime, timezone
import re
from pathlib import Path
from guards import GIB, SCOPE, ancestors, fresh, require
from package_integrity import json_file
from proof import file_pin, digest
from supervision import check_sample

BUDGET_MINIMUMS = {"source_staging_bytes": 4 * 1048576, "evidence_bytes": 256 * 1048576,
                   "export_bytes": 256 * 1048576, "exchange_bytes": 4 * 1048576,
                   "docker_image_bytes": 1, "docker_writable_bytes": 1}


def reference(data):
    path = Path(data["path"])
    file_pin(path, data["sha256"])
    return json_file(path)


def recent(record, seconds=60):
    instant = datetime.fromisoformat(record["at_gst"])
    require(instant.utcoffset().total_seconds() == 14400, "GST provenance time")
    require(0 <= (datetime.now(timezone.utc) - instant).total_seconds() <= seconds, "fresh provenance")


def carried(data, device):
    baseline = reference(data["baseline"])
    chain = reference(data["peak_chain"])
    require(chain["complete"] is True, "external complete peak chain required")
    require(chain["baseline_sha256"] == data["baseline"]["sha256"], "immutable original baseline binding")
    require(baseline[data["device_key"]] == device, "original baseline filesystem device")
    rows = [reference(row) for row in chain["observations"]]
    require(bool(rows), "all carried observations required")
    peaks = [row["peak_used_bytes"] for row in rows]
    require(all(type(value) is int for value in peaks), "integer carried peaks")
    maximum = max(peaks + [baseline[data["used_bytes_key"]]])
    require(chain["peak_used_bytes"] == maximum, "carried peak cannot lower or omit supplied peaks")
    recent(chain)
    return baseline[data["used_bytes_key"]], maximum, {"mode": "carried", "input": data, "baseline": baseline, "chain": chain}


def provenance(data, sample, device):
    require(data["mode"] in ("fresh", "carried"), "explicit baseline mode")
    if data["mode"] == "carried":
        return carried(data, device)
    require(set(data) == {"mode"}, "fresh baseline cannot replace supplied carried provenance")
    return sample["used_bytes"], sample["used_bytes"], {"mode": "fresh", "baseline": sample, "device": device}


def validate_config(config, exchange):
    require(config["schema"] == "fluss-operator-config-v1", "operator config schema")
    require(re.fullmatch(r"fluss-[a-z0-9-]+-[a-f0-9]{16}", config["run_id"]), "fresh operator run identity")
    root = Path(config["root"])
    require(root == Path("/var/tmp/technical-blogs-" + config["run_id"]), "exact fresh owned root")
    fresh(root)
    fresh(exchange)
    require(exchange.parent.is_dir(), "exchange existing parent required")
    require(root not in exchange.parents and exchange not in root.parents, "exchange separate from owned root")
    require(config["ports"] == {"coordinator": 9123, "zookeeper": 2181, "service": 18080}, "exact internal ports; no host publishing")
    require(bool(config["hostname"]), "explicit actual hostname")
    budget = config["outside_budget"]
    require(set(budget["limits"]) == set(BUDGET_MINIMUMS), "all outside allocations explicitly bounded")
    for name, minimum in BUDGET_MINIMUMS.items():
        require(type(budget["limits"][name]) is int and budget["limits"][name] >= minimum, "explicit bound: " + name)
    require(bool(budget["provenance"]), "operator measured budget provenance")
    reference(budget["provenance"])
    config["outside_total_bytes"] = sum(budget["limits"].values())
    return config


def authorize(grant, config, manifest, foreign_sha):
    require(grant["schema"] == "fluss-operator-authorization-v1", "operator authorization schema")
    require(grant["approved"] is True, "actual explicit operator authorization required")
    require(grant["scope"] == SCOPE, "exact unchanged allocation/mount/cleanup scope")
    require(grant["manifest_sha256"] == manifest, "authorization package binding")
    require(grant["run_id"] == config["run_id"] and grant["root"] == config["root"], "authorization owned identity")
    require(grant["foreign_snapshot_sha256"] == foreign_sha, "fresh CURRENT foreign authorization binding")
    require(bool(grant["operator"]) and bool(grant["decision_provenance"]), "external operator decision provenance")
    reference(grant["decision_provenance"])
    require(grant["baseline_mode"] == config["baseline"]["mode"], "authorized baseline mode cannot reset")
    require(grant["baseline_provenance"] == config["baseline"], "authorized exact baseline provenance")
    require(grant["outside_budget"] == config["outside_budget"], "authorized exact outside allocation budgets")


def reserve_budget(sample, baseline, config):
    demand = 4 * GIB + config["outside_total_bytes"]
    used = sample["used_bytes"] + demand
    free = sample["free_bytes"] - demand
    import math
    projected = {**sample, "free_bytes": free, "used_bytes": used,
                 "usage_percent": math.ceil(100 * used / (used + free)),
                 "growth_bytes": max(sample["peak_used_bytes"], used) - baseline}
    check_sample(projected, preboot=True)
