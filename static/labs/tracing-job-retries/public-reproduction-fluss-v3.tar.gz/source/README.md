# Fluss retry lab, portable wrapper v2

Historical execution: 5 October 2026 GST, seven cases and 234 assertions. The new wrapper was not executed. Runtime/build source and E2E specification are byte-identical to the bound historical input. This replacement README, source inventory and guide have new hashes; they do not inherit runtime credit.

Follow [the single portable guide](../evidence/RUNTIME_README.md). Extract the package root containing source/, evidence/, assets/ and captures/. Source dependencies remain external. Java17, Maven3.9.9 and the recorded image Python3.12.3 are required by the reproduction environment. Controller packaging uses Python3.10-compatible standard library.

The deterministic HTTP fixture and serial worker preserve storage across process restarts. No real LLM, host-loss, concurrent-worker or lost-response result is claimed. Historical raw material remains privately preserved. Only explicitly selected synthetic records are in this derivative.
