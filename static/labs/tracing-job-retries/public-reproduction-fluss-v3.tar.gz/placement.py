"""Exact placement and ext4 identity checks; no alternate workspace."""

import json
import os
from pathlib import Path, PurePosixPath
import stat
from guards import GIB, ancestors, require

LAYOUT = {"archive": "/lab/runtime/fluss-1.0.0-bin.tgz",
          "cluster": "/lab/runtime/attempt-02/fluss-1.0.0",
          "repository": "/lab/runtime/m2", "target": "/lab/runtime/build-target",
          "data": "/lab/runtime/run-02-data"}


def check_layout(layout):
    require(layout == LAYOUT, "exact reserved workspace layout")
    for path in layout.values():
        require(PurePosixPath(path).is_relative_to("/lab/runtime"), "workspace escape")


def filesystem_record(text, loop):
    rows = text.splitlines()
    require(len(rows) == 2, "one actual workspace filesystem")
    fields = rows[1].split()
    require(len(fields) == 6, "workspace df schema")
    source, kind, target, size, available, use = fields
    require(source == loop, "exact workspace loop identity")
    require(kind == "ext4" and target == "/lab/runtime", "reserved ext4 workspace")
    require(3.5 * GIB <= int(size) <= 4 * GIB, "exact4GiB ext4 capacity")
    require(int(use.rstrip("%")) < 85, "ext4 used_percent must remain below85")
    return {"raw_df": text, "source": source, "fstype": kind, "target": target,
            "capacity_bytes": int(size), "available_bytes": int(available), "used_percent": int(use.rstrip("%"))}


def mount_table(text):
    rows = []
    for line in text.splitlines():
        left, right = line.split(" - ", 1)
        fields, filesystem = left.split(), right.split()
        rows.append({"id": fields[0], "parent": fields[1], "device": fields[2], "root": fields[3],
                     "target": fields[4], "options": fields[5], "fstype": filesystem[0], "source": filesystem[1]})
    return rows


def workspace_mount(root, loop, rows):
    matching = [row for row in rows if row["target"] == str(root)]
    require(len(matching) == 1, "one exact workspace mount")
    row = matching[0]
    require(not any("\\" in value for value in row.values()), "unescaped exact workspace mount identity")
    require(row["source"] == loop and row["fstype"] == "ext4" and row["root"] == "/", "exact whole ext4 loop mount")
    nested = [item for item in rows if Path(item["target"]) != root and root in Path(item["target"]).parents]
    require(not nested, "no nested or bind workspace mount")
    return row


def node_identity(path, device=None):
    value = path.lstat()
    require(not stat.S_ISLNK(value.st_mode), "workspace symlink forbidden")
    require(stat.S_ISDIR(value.st_mode) or stat.S_ISREG(value.st_mode), "workspace regular ancestor")
    if device is not None:
        require(value.st_dev == device, "workspace ancestor on exact loop device")
    return [value.st_dev, value.st_ino]


def existing_ancestors(root, path, device):
    require(path.is_absolute() and root in path.parents, "workspace path below exact root")
    require(path.resolve(strict=False) == path, "resolved workspace path unchanged")
    result = {}
    for parent in [*reversed(path.parents), path]:
        if parent.exists() or parent.is_symlink():
            owned = parent == root or root in parent.parents
            result[str(parent)] = node_identity(parent, device if owned else None)
    require(str(root) in result, "nearest existing parent belongs to workspace")
    return {name: value for name, value in result.items() if Path(name) == root or root in Path(name).parents}


def validate_paths(root, paths, expected, previous=None, rows=None):
    root = Path(root)
    rows = mount_table(Path("/proc/self/mountinfo").read_text()) if rows is None else rows
    mounted = workspace_mount(root, expected["loop"], rows)
    current = node_identity(root)
    require(current == [expected["device"], expected["inode"]], "bound workspace device/inode identity")
    major, minor = map(int, mounted["device"].split(":"))
    require(os.makedev(major, minor) == current[0], "mount device matches actual workspace inode")
    capacity(root)
    ancestors = {}
    for path in paths:
        ancestors.update(existing_ancestors(root, Path(path), current[0]))
    state = {"mount": mounted, "ancestors": ancestors}
    if previous is not None:
        require(mounted == previous["mount"], "unchanged mount generation and identity")
        require(all(ancestors.get(name) == value for name, value in previous["ancestors"].items()), "unchanged existing workspace inodes")
    return state


def capacity(root):
    value = os.statvfs(root)
    size = value.f_blocks * value.f_frsize
    used = value.f_blocks - value.f_bfree
    denominator = used + value.f_bavail
    require(3.5 * GIB <= size <= 4 * GIB, "exact4GiB workspace capacity before allocation")
    require(denominator > 0, "nonempty ext4 capacity")
    percent = (100 * used + denominator - 1) // denominator
    require(percent < 85, "unchanged ext4 used_percent below85 before allocation")


def workspace_paths(root):
    relative = ["fluss-1.0.0-bin.tgz", "fluss-1.0.0-bin.tgz.sha512", "attempt-02", "attempt-02/fluss-1.0.0",
                "attempt-02/fluss-1.0.0/conf", "attempt-02/fluss-1.0.0/log", "attempt-02/remote-data",
                "attempt-02/zookeeper-data", "m2", "build-target", "build-target/classes/lab/retry", "run-02-data"]
    return [Path(root) / name for name in relative]


def host_paths(owned):
    info = owned.mount.stat()
    expected = {"loop": owned.loop, "device": info.st_dev, "inode": info.st_ino}
    if hasattr(owned, "workspace_expected"):
        require(expected == owned.workspace_expected, "unchanged host loop workspace")
    previous = getattr(owned, "workspace_state", None)
    owned.workspace_state = validate_paths(owned.mount, workspace_paths(owned.mount), expected, previous)
    owned.workspace_expected = expected
    return expected


def container_paths(layout=None):
    layout = LAYOUT if layout is None else layout
    check_layout({name: str(path) for name, path in layout.items()})
    expected_path = Path("/lab/staging/workspace-expected.json")
    ancestors(expected_path)
    require(expected_path.stat().st_size <= 65536, "bounded external workspace identity")
    expected = json.loads(expected_path.read_text())
    state_path = Path("/lab/staging/workspace-state.json")
    ancestors(state_path)
    previous = None
    if state_path.exists():
        require(not state_path.is_symlink() and state_path.stat().st_size <= 65536, "bounded regular workspace state")
        previous = json.loads(state_path.read_text())
    state = validate_paths(Path("/lab/runtime"), workspace_paths("/lab/runtime"), expected, previous)
    raw = json.dumps(state, sort_keys=True) + "\n"
    require(len(raw) <= 65536, "bounded workspace state allocation")
    state_path.write_text(raw)
    return state
