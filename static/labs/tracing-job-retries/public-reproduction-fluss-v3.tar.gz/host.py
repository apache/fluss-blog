"""Exact existing host/tool preflight, no host installation or configuration."""

import json
import os
from pathlib import Path
import platform
import shutil
import socket
import sys
from guards import require
from ownership import containers
from supervision import output, timestamp


def primary(config, exchange):
    require(os.geteuid() == 0, "authorized root execution required")
    require(platform.system() == "Linux" and platform.machine() == "x86_64", "native Linux AMD64 required")
    require(socket.gethostname() == config["hostname"], "actual operator hostname")
    require(sys.version_info[:3] == (3, 10, 12) and sys.executable == "/usr/bin/python3", "system Python3.10.12 required")
    require(Path("/proc/sys/vm/max_map_count").read_text().strip() == "65530", "original sysctl65530; never change it")
    version = json.loads(output(["docker", "version", "--format", "{{json .Server}}"] ))
    require(version["Version"] == "29.1.3" and version["Os"] == "linux" and version["Arch"] == "amd64", "actual Docker29.1.3 Linuxamd64")
    info = json.loads(output(["docker", "info", "--format", "{{json .}}"] ))
    device = os.stat(Path(config["root"]).parent).st_dev
    require(os.stat(info["DockerRootDir"]).st_dev == device, "same host/Docker filesystem")
    require(os.stat(exchange.parent).st_dev == device, "same budgeted exchange filesystem")
    tools()
    return {"server": version, "info": info, "python": sys.version, "sysctl": 65530,
            "at_gst": timestamp(), "hostname": socket.gethostname(), "device": device}


def tools():
    for tool in ("fallocate", "findmnt", "losetup", "mount", "umount", "sync", "fuser"):
        require(shutil.which(tool) is not None, "missing existing host tool: " + tool)
    require(Path("/usr/sbin/mkfs.ext4").is_file(), "existing mkfs.ext4 required")


def fresh_slot(name):
    rows = containers()
    require(all(item["Name"] != "/" + name for item in rows), "fresh container name")
    require(name not in output(["docker", "network", "ls", "--format", "{{.Name}}"]).splitlines(), "fresh network name")
    for item in rows:
        labels = item["Config"].get("Labels") or {}
        require(not any(labels.get(key) for key in ("fluss-guarded-owner", "io.x-k8s.kind.cluster",
                    "istio-guarded-owner", "technical-blog-run")), "exclusive free lab slot")
    require(not output(["docker", "network", "ls", "-q", "--filter", "label=technical-blog-run"]).strip(), "exclusive free network slot")
