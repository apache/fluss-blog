"""Verify exact regular source package before invoking any runtime operation."""

import json
from pathlib import PurePosixPath
from guards import ancestors, require
from proof import digest, file_pin, source_hashes


def canonical(name):
    path = PurePosixPath(name)
    require(not path.is_absolute() and ".." not in path.parts, "member path escape")
    require(name == path.as_posix() and bool(path.parts), "canonical member path")
    return name


def verify_package(root, expected):
    file_pin(root / "PUBLIC_MANIFEST.json", expected)
    data = json.loads((root / "PUBLIC_MANIFEST.json").read_text())
    require(data["schema"] == "fluss-public-manifest-v3", "public manifest schema")
    pins = data["files"]
    require(set(data) == {"schema", "files", "projection"}, "closed public manifest metadata")
    expected_projection = {"schema": "fluss-public-projection-v1", "producer": pins["projection.py"],
                           "checker": pins["verification.py"], "privacy_schema": pins["public_schema.py"]}
    require(data["projection"] == expected_projection, "honest declared projection/checker metadata")
    require(len(pins) <= 64, "bounded public package")
    for path in root.rglob("*"):
        require(not path.is_symlink(), "package symlink entry")
    actual = {p.relative_to(root).as_posix() for p in root.rglob("*") if p.is_file()}
    require(actual == set(pins) | {"PUBLIC_MANIFEST.json"}, "exact fresh package file set")
    for name, pin in pins.items():
        file_pin(root / canonical(name), pin["sha256"], pin["bytes"])
    source_hashes(root / "source", root / "source-manifest.json")
    return data


def json_file(path):
    ancestors(path)
    require(path.is_file() and path.stat().st_size <= 4 * 1048576, "bounded external JSON")
    return json.loads(path.read_text())
