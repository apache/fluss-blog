"""One bounded public projection archive frozen under the original live monitor."""

import io
import json
import secrets
import tarfile
from guards import fresh, require
from proof import digest, save
from package_integrity import verify_package
from projection import project, raw_pin
from public_schema import MAX_EXPORT, SCHEMA, VALIDATORS, BINARY


def evidence_allowed(name):
    return name in set(VALIDATORS) | BINARY | {"workload-streams.jsonl"}


def snapshot_monitor(owned, monitor):
    with monitor.sample_lock:
        source = owned.evidence / "host-monitor.jsonl"
        require(source.stat().st_size <= 4 * 1048576, "bounded private monitor snapshot")
        (owned.evidence / "host-monitor-export.jsonl").write_bytes(source.read_bytes())
        save(owned.evidence / "export-monitor.json", {"baseline": monitor.baseline, "peak": monitor.peak,
             "thread_alive": monitor.thread.is_alive(), "error": str(monitor.error), "last_sample": monitor.latest})


def files(package, owned):
    verify_package(package, owned.manifest)
    manifest_raw = (package / "PUBLIC_MANIFEST.json").read_bytes()
    require(raw_pin(manifest_raw)["sha256"] == owned.manifest, "frozen manifest bytes before public export")
    manifest = json.loads(manifest_raw)
    result = {"package/PUBLIC_MANIFEST.json": manifest_raw}
    for name, pin in manifest["files"].items():
        raw = (package / name).read_bytes()
        require(raw_pin(raw) == pin, "frozen public package bytes; no unpinned diagnostic export")
        result["package/" + name] = raw
    result.update({"evidence/" + name: raw for name, raw in project(owned, package).items()})
    require(len(result) <= 1024, "bounded export members")
    require(sum(len(raw) for raw in result.values()) <= MAX_EXPORT, "bounded export content")
    return result


def add_member(archive, name, raw):
    info = tarfile.TarInfo(name)
    info.size, info.mode = len(raw), 0o600
    archive.addfile(info, io.BytesIO(raw))


def checker_pins(package):
    return {"projection_schema": SCHEMA, "projection_sha256": digest(package / "projection.py"),
            "checker_sha256": digest(package / "verification.py"), "privacy_schema_sha256": digest(package / "public_schema.py"),
            "verifier_sha256": digest(package / "verify_export.py")}


def seal(package, owned, monitor, exchange):
    snapshot_monitor(owned, monitor)
    members = files(package, owned)
    index = {"schema": "fluss-evidence-index-v2", "run_id": owned.name, "manifest_sha256": owned.manifest,
             **checker_pins(package), "files": {name: raw_pin(raw) for name, raw in members.items()}}
    index_path = exchange / "evidence-index.json"
    save(index_path, index)
    archive_path = exchange / "evidence.tar.gz"
    fresh(archive_path)
    with tarfile.open(archive_path, "x:gz") as archive:
        for name, raw in sorted(members.items()):
            monitor.check(force=True)
            add_member(archive, name, raw)
        add_member(archive, "evidence-index.json", index_path.read_bytes())
    require(archive_path.stat().st_size <= MAX_EXPORT, "bounded final archive")
    owned.export_checks = {"checked_result_sha256": raw_pin(members["evidence/result.json"])["sha256"],
                           "checked_build_sha256": raw_pin(members["evidence/build.json"])["sha256"],
                           "checked_cleanup_sha256": raw_pin(members["evidence/observations.json"])["sha256"]}
    offer = {"schema": "fluss-export-offer-v2", "run_id": owned.name, "manifest_sha256": owned.manifest,
             "archive_sha256": digest(archive_path), "archive_bytes": archive_path.stat().st_size,
             "archive": str(archive_path), "index_sha256": digest(index_path), "nonce": secrets.token_hex(32),
             **checker_pins(package)}
    save(exchange / "offer.json", offer)
    return offer
