"""Closed public projection types; arbitrary strings and raw diagnostics are forbidden."""

from datetime import datetime
import json
import re
from guards import require
from placement import workspace_paths
from pathlib import Path

SCHEMA = "fluss-public-projection-v1"
MAX_EXPORT = 256 * 1048576
CASES = {"baseline", "repeat-compute", "before-http", "after-commit", "unknown", "duplicate-event", "conflicting-action"}
STEPS = ["allocate4GiB", "format-nodiscard", "attach-loop", "mount-owned", "network-create", "pull-pinned-image",
         "container-create", "container-apt-update", "container-packages", "prepare", "build", "dependencies", "start", "verify", "stop"]
CLEAN = ["remove-owned-container", "remove-owned-network", "sync-owned-data", "unmount-owned", "detach-owned-loop"]
CHECKS = ["observe-cleanup-" + name for name in ("containers", "networks", "mounts", "loops", "file")]
HEAVY = ["packages", "prepare", "build", "dependencies", "start", "verify", "stop"]
OPERATIONS = set(STEPS + CLEAN + CHECKS + [prefix + name for prefix in ("workspace-", "layer-", "paths-before-", "paths-after-") for name in HEAVY])


def exact(value, fields):
    require(type(value) is dict and set(value) == set(fields), "closed public object fields")


def integer(value):
    require(type(value) is int and 0 <= value <= 2**63 - 1, "public bounded integer")


def signed(value):
    require(type(value) is int and -128 <= value <= 255, "public process exit")


def boolean(value):
    require(type(value) is bool, "public boolean")


def hexdigest(value):
    require(type(value) is str and re.fullmatch("[0-9a-f]{64}", value), "public SHA256/ID")


def timestamp(value):
    require(type(value) is str and re.fullmatch(r"[0-9T:.+\-]+", value), "public timestamp alphabet")
    require(datetime.fromisoformat(value).utcoffset().total_seconds() == 14400, "public GST timestamp")


def run_id(value):
    require(type(value) is str and re.fullmatch(r"fluss-[a-z0-9-]+-[0-9a-f]{16}", value), "public run ID")


def loop(value):
    require(type(value) is str and re.fullmatch(r"/dev/loop[0-9]+", value), "public loop ID")


def choice(*values):
    def validate(value):
        require(value in values, "public finite vocabulary")
    return validate


def array(validator):
    def validate(value):
        require(type(value) is list and len(value) <= 65536, "bounded public array")
        for row in value:
            validator(row)
    return validate


def object_type(fields):
    def validate(value):
        exact(value, fields)
        for name, validator in fields.items():
            validator(value[name])
    return validate


PIN = object_type({"bytes": integer, "sha256": hexdigest})
PROCESS = {"pid": integer, "exit_code": signed, "started_gst": timestamp, "ended_gst": timestamp,
           "drained": boolean, "timed_out": boolean, "raw_sha256": hexdigest}
PHASE = object_type({**PROCESS, "operation": choice(*OPERATIONS), "process_group": integer,
                     "natural_exit": boolean, "stdout": PIN, "stderr": PIN, "observation_sha256": hexdigest,
                     "output_sha256": hexdigest, "subject_sha256": hexdigest})
WORKER = object_type({**PROCESS, "serial": integer, "role": choice("service", "kill", "recover", "other"),
                      "name_sha256": hexdigest, "job_sha256": hexdigest, "jar_sha256": hexdigest,
                      "stdout": PIN, "stderr": PIN})
ASSERTION = object_type({"name_sha256": hexdigest, "expected_sha256": hexdigest, "observed_sha256": hexdigest})
SAMPLE = object_type({"used_bytes": integer, "peak_used_bytes": integer, "free_bytes": integer,
                      "usage_percent": integer, "memory_available_bytes": integer, "growth_bytes": integer,
                      "preboot": boolean, "at_gst": timestamp})
PATH_NAMES = {"/lab/runtime"} | {str(path) for path in workspace_paths("/lab/runtime")}
PATH_NAMES |= {str(parent) for path in workspace_paths("/lab/runtime") for parent in path.parents if Path("/lab/runtime") in parent.parents}
ANCESTOR = object_type({"path": choice(*PATH_NAMES), "device": integer, "inode": integer})
PATH_STATE = object_type({"mount_id": integer, "parent_id": integer, "major": integer, "minor": integer,
                          "source": loop, "fstype": choice("ext4"), "root": choice("/"),
                          "target": choice("/lab/runtime"), "options_sha256": hexdigest,
                          "ancestors": array(ANCESTOR)})
WORKSPACE = object_type({"phase": choice(*HEAVY), "source": loop, "fstype": choice("ext4"),
                         "target": choice("/lab/runtime"), "capacity_bytes": integer,
                         "available_bytes": integer, "used_percent": integer, "layer_bytes": integer,
                         "df_sha256": hexdigest, "layer_sha256": hexdigest,
                         "paths_before": PATH_STATE, "paths_after": PATH_STATE})
CAPS = object_type({"memory_bytes": integer, "swap_bytes": integer, "nano_cpus": integer, "pids": integer,
                   "privileged": boolean, "capabilities_count": integer, "published_ports_count": integer,
                   "log_type": choice("json-file"), "log_max_size": choice("4m"), "log_max_file": choice("2")})
IDENTITY = object_type({"container_id": hexdigest, "network_id": hexdigest, "image_id": hexdigest,
                       "image_digest": hexdigest, "loop": loop, "image_path_sha256": hexdigest,
                       "mount_path_sha256": hexdigest, "image_device": integer, "image_inode": integer,
                       "size": integer, "allocated_bytes": integer, "format": choice("mkfs.ext4 -m0 -E nodiscard"),
                       "caps": CAPS, "writable_budget": integer, "foreign_before_sha256": hexdigest,
                       "foreign_after_sha256": hexdigest, "inspect_sha256": hexdigest})
CLEANUP = object_type({"container_id": hexdigest, "network_id": hexdigest, "loop": loop,
                      "image_path_sha256": hexdigest, "image_device": integer, "image_inode": integer,
                      "remaining_container_ids": array(hexdigest), "remaining_network_ids": array(hexdigest),
                      "remaining_mount_sha256": array(hexdigest), "loop_observation": PIN,
                      "file_errno": integer, "file_path_sha256": hexdigest, "raw_sha256": hexdigest})
BUILD = object_type({"source_manifest_sha256": hexdigest, "jar_sha256": hexdigest, "jar_bytes": integer,
                    "FlussStore_class_sha256": hexdigest, "image": choice("docker.io/library/maven@sha256:82e47241881f23ad774f5db8829efca15758e8fdb5b1d64ea9f8d6420a85068e"),
                    "jar_path_tested": choice("/lab/runtime/build-target/fluss-retry-lab.jar"), "raw_sha256": hexdigest})
RESULT = object_type({"run_id": run_id, "cases": array(choice(*CASES)), "assertions": array(ASSERTION),
                     "workers": array(WORKER), "error_count": integer, "cleanup_error_count": integer,
                     "source_sha256": hexdigest, "raw_sha256": hexdigest})
OBSERVATIONS = object_type({"schema": choice(SCHEMA), "identity": IDENTITY, "cleanup": CLEANUP,
                           "workspaces": array(WORKSPACE), "backend_before": array(integer),
                           "backend_after": array(integer), "release_sha512": choice("4cc134d1c5e7b9b07754b4d38903b9c6e4075d66aa7cf04eb3b053fa5095266f1d141e147417d292b3e93b642b24ea06630709de85562c3a829b640ccb7d52ca"),
                           "release_bytes": integer, "config_before_sha256": hexdigest, "config_tested_sha256": hexdigest})
MONITOR = object_type({"schema": choice(SCHEMA), "baseline": integer, "peak": integer,
                      "thread_alive": boolean, "error_count": integer, "samples": array(SAMPLE)})
STREAM = object_type({"worker": integer, "channel": choice("stdout", "stderr"), "line": integer,
                     "bytes": integer, "sha256": hexdigest,
                     "kind": choice("ACK", "RESULT", "REPLAY", "BARRIER", "FAILURE", "diagnostic")})
VALIDATORS = {"observations.json": OBSERVATIONS, "build.json": BUILD, "result.json": RESULT,
              "phases.json": array(PHASE), "monitor.json": MONITOR}
BINARY = {"tested.jar", "FlussStore.class", "build.pom.xml"}


def unique_object(pairs):
    value = {}
    for key, item in pairs:
        require(key not in value, "duplicate public JSON key")
        value[key] = item
    return value


def decode(raw):
    return json.loads(raw, object_pairs_hook=unique_object)


def validate_member(name, raw):
    if name in BINARY:
        return
    require(name == "workload-streams.jsonl" or name in VALIDATORS, "exact public evidence member")
    if name == "workload-streams.jsonl":
        for line in raw.splitlines():
            STREAM(decode(line))
        return
    VALIDATORS[name](decode(raw))
